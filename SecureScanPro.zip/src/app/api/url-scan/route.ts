import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Phishing and malicious URL patterns
const PHISHING_PATTERNS = [
  // Fake login pages
  { pattern: 'paypal.com.verify', name: 'PayPal Phishing', severity: 'critical' as const },
  { pattern: 'paypal.com.secure', name: 'PayPal Phishing', severity: 'critical' as const },
  { pattern: 'amazon.com.verify', name: 'Amazon Phishing', severity: 'critical' as const },
  { pattern: 'amazon.com.secure', name: 'Amazon Phishing', severity: 'critical' as const },
  { pattern: 'appleid.apple.com.verify', name: 'Apple ID Phishing', severity: 'critical' as const },
  { pattern: 'icloud.com.verify', name: 'iCloud Phishing', severity: 'critical' as const },
  { pattern: 'microsoft.com.verify', name: 'Microsoft Phishing', severity: 'critical' as const },
  { pattern: 'office365.com.verify', name: 'Office 365 Phishing', severity: 'critical' as const },
  { pattern: 'gmail.com.verify', name: 'Gmail Phishing', severity: 'critical' as const },
  { pattern: 'google.com.verify', name: 'Google Phishing', severity: 'critical' as const },
  { pattern: 'facebook.com.verify', name: 'Facebook Phishing', severity: 'critical' as const },
  { pattern: 'instagram.com.verify', name: 'Instagram Phishing', severity: 'critical' as const },
  { pattern: 'twitter.com.verify', name: 'Twitter Phishing', severity: 'critical' as const },
  { pattern: 'banking-', name: 'Fake Banking Site', severity: 'critical' as const },
  { pattern: '-banking', name: 'Fake Banking Site', severity: 'critical' as const },
  { pattern: '-login-', name: 'Suspicious Login Page', severity: 'high' as const },
  { pattern: '-secure-', name: 'Suspicious Secure Page', severity: 'high' as const },
  { pattern: '-verify-', name: 'Suspicious Verify Page', severity: 'high' as const },
  { pattern: '-account-', name: 'Suspicious Account Page', severity: 'medium' as const },
  
  // Tech support scams
  { pattern: 'microsoft-support', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'windows-support', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'apple-support', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'computer-support', name: 'Tech Support Scam', severity: 'critical' as const },
  
  // Malware download patterns
  { pattern: 'free-download-crack', name: 'Crack/Piracy Site', severity: 'high' as const },
  { pattern: 'warez', name: 'Warez/Piracy Site', severity: 'high' as const },
  { pattern: 'serial-key', name: 'Serial Key Site', severity: 'high' as const },
  { pattern: 'keygen', name: 'Keygen Site', severity: 'high' as const },
  
  // Suspicious TLDs
  { pattern: '.tk/', name: 'Suspicious TLD (.tk)', severity: 'medium' as const },
  { pattern: '.ml/', name: 'Suspicious TLD (.ml)', severity: 'medium' as const },
  { pattern: '.ga/', name: 'Suspicious TLD (.ga)', severity: 'medium' as const },
  { pattern: '.cf/', name: 'Suspicious TLD (.cf)', severity: 'medium' as const },
  { pattern: '.gq/', name: 'Suspicious TLD (.gq)', severity: 'medium' as const },
  { pattern: '.xyz/', name: 'Suspicious TLD (.xyz)', severity: 'low' as const },
  
  // IP address URLs (often used for phishing)
  { pattern: /https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/, name: 'IP Address URL', severity: 'medium' as const, isRegex: true },
  
  // URL shortener abuse (check the final destination)
  { pattern: 'bit.ly', name: 'URL Shortener', severity: 'low' as const },
  { pattern: 'tinyurl.com', name: 'URL Shortener', severity: 'low' as const },
  { pattern: 'goo.gl', name: 'URL Shortener', severity: 'low' as const },
  { pattern: 't.co', name: 'URL Shortener', severity: 'low' as const },
]

// Malicious content patterns in page content
const MALICIOUS_CONTENT_PATTERNS = [
  { pattern: 'Your computer has been infected', name: 'Fake Virus Alert', severity: 'critical' as const },
  { pattern: 'Your computer is infected', name: 'Fake Virus Alert', severity: 'critical' as const },
  { pattern: 'Your PC is infected', name: 'Fake Virus Alert', severity: 'critical' as const },
  { pattern: 'Windows has detected a virus', name: 'Fake Virus Alert', severity: 'critical' as const },
  { pattern: 'Microsoft has detected', name: 'Fake Alert', severity: 'critical' as const },
  { pattern: 'Call Microsoft', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'Call Apple Support', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'Call Windows Support', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'Toll-Free Technical Support', name: 'Tech Support Scam', severity: 'critical' as const },
  { pattern: 'Your system is at risk', name: 'Fake Alert', severity: 'high' as const },
  { pattern: 'Immediate action required', name: 'Urgency Scam', severity: 'high' as const },
  { pattern: 'Your account will be suspended', name: 'Account Scam', severity: 'high' as const },
  { pattern: 'Verify your account now', name: 'Phishing Attempt', severity: 'high' as const },
  { pattern: 'Your password has expired', name: 'Phishing Attempt', severity: 'high' as const },
  { pattern: 'Update your payment', name: 'Payment Scam', severity: 'high' as const },
  { pattern: 'Confirm your identity', name: 'Identity Scam', severity: 'high' as const },
  { pattern: 'You have won', name: 'Lottery Scam', severity: 'medium' as const },
  { pattern: 'You have been selected', name: 'Prize Scam', severity: 'medium' as const },
  { pattern: 'Bitcoin', name: 'Cryptocurrency Mention', severity: 'low' as const },
  { pattern: 'Cryptocurrency', name: 'Cryptocurrency Mention', severity: 'low' as const },
  { pattern: 'Download Flash Player', name: 'Fake Download', severity: 'high' as const },
  { pattern: 'Update your browser', name: 'Fake Update', severity: 'high' as const },
  { pattern: 'Your browser is outdated', name: 'Fake Update', severity: 'high' as const },
  { pattern: 'Your plugin is outdated', name: 'Fake Update', severity: 'high' as const },
]

// Suspicious form patterns
const SUSPICIOUS_FORM_PATTERNS = [
  { pattern: 'type="password"', name: 'Password Field', severity: 'low' as const },
  { pattern: 'type="credit card"', name: 'Credit Card Field', severity: 'medium' as const },
  { pattern: 'name="ssn"', name: 'SSN Field', severity: 'high' as const },
  { pattern: 'name="social"', name: 'Social Security Field', severity: 'high' as const },
  { pattern: 'cvv', name: 'CVV Field', severity: 'medium' as const },
  { pattern: 'card number', name: 'Card Number Field', severity: 'medium' as const },
]

interface URLThreat {
  type: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  description: string
  location: string
}

interface URLScanResult {
  url: string
  finalUrl: string
  title: string
  status: 'safe' | 'suspicious' | 'malicious' | 'error'
  threatLevel: number
  threats: URLThreat[]
  ssl: boolean
  domainAge: string
  redirects: number
  contentAnalysis: {
    hasLoginForm: boolean
    hasPasswordField: boolean
    hasDownloadButton: boolean
    hasExternalScripts: boolean
    scriptCount: number
    iframeCount: number
  }
  recommendations: string[]
}

function parseUrl(url: string): { domain: string; protocol: string; path: string } | null {
  try {
    const parsed = new URL(url)
    return {
      domain: parsed.hostname,
      protocol: parsed.protocol,
      path: parsed.pathname + parsed.search
    }
  } catch {
    return null
  }
}

function analyzeUrlPatterns(url: string): URLThreat[] {
  const threats: URLThreat[] = []
  const urlLower = url.toLowerCase()
  
  for (const pattern of PHISHING_PATTERNS) {
    const isMatch = pattern.isRegex 
      ? (pattern.pattern as RegExp).test(url)
      : urlLower.includes(pattern.pattern.toString().toLowerCase())
    
    if (isMatch) {
      threats.push({
        type: pattern.name.includes('Phishing') ? 'Phishing' : 
              pattern.name.includes('Scam') ? 'Scam' : 
              pattern.name.includes('Suspicious') ? 'Suspicious' : 'Warning',
        severity: pattern.severity,
        description: `${pattern.name} erkannt in URL`,
        location: 'URL'
      })
    }
  }
  
  return threats
}

function analyzeContent(html: string): { threats: URLThreat[], contentAnalysis: URLScanResult['contentAnalysis'] } {
  const threats: URLThreat[] = []
  const htmlLower = html.toLowerCase()
  
  // Analyze content patterns
  for (const pattern of MALICIOUS_CONTENT_PATTERNS) {
    if (htmlLower.includes(pattern.pattern.toLowerCase())) {
      threats.push({
        type: pattern.name.includes('Scam') ? 'Scam' : 
              pattern.name.includes('Alert') ? 'Fake Alert' : 
              pattern.name.includes('Phishing') ? 'Phishing' : 'Warning',
        severity: pattern.severity,
        description: `${pattern.name} im Seiteninhalt gefunden`,
        location: 'Content'
      })
    }
  }
  
  // Analyze page structure
  const contentAnalysis: URLScanResult['contentAnalysis'] = {
    hasLoginForm: htmlLower.includes('<form') && (htmlLower.includes('password') || htmlLower.includes('login') || htmlLower.includes('signin')),
    hasPasswordField: htmlLower.includes('type="password"') || htmlLower.includes("type='password'"),
    hasDownloadButton: htmlLower.includes('download') && (htmlLower.includes('button') || htmlLower.includes('href')),
    hasExternalScripts: /src=["']https?:\/\/(?!([^\/]+\.)?(google\.com|googleapis\.com|gstatic\.com|cloudflare\.com|jsdelivr\.net|unpkg\.com|cdnjs\.cloudflare\.com))/i.test(html),
    scriptCount: (html.match(/<script/gi) || []).length,
    iframeCount: (html.match(/<iframe/gi) || []).length
  }
  
  // Check for hidden iframes (often malicious)
  if (contentAnalysis.iframeCount > 0 && /<iframe[^>]*(hidden|display:\s*none|width:\s*0|height:\s*0)/gi.test(html)) {
    threats.push({
      type: 'Malicious',
      severity: 'high',
      description: 'Versteckte IFrames gefunden - möglicherweise bösartig',
      location: 'Content'
    })
  }
  
  // Too many scripts can be suspicious
  if (contentAnalysis.scriptCount > 50) {
    threats.push({
      type: 'Suspicious',
      severity: 'medium',
      description: `Ungewöhnlich viele Scripts (${contentAnalysis.scriptCount}) auf der Seite`,
      location: 'Content'
    })
  }
  
  return { threats, contentAnalysis }
}

function calculateThreatLevel(threats: URLThreat[]): number {
  let score = 0
  
  for (const threat of threats) {
    switch (threat.severity) {
      case 'critical': score += 30; break
      case 'high': score += 20; break
      case 'medium': score += 10; break
      case 'low': score += 3; break
    }
  }
  
  return Math.min(100, score)
}

function generateRecommendations(result: URLScanResult): string[] {
  const recommendations: string[] = []
  
  if (result.status === 'malicious') {
    recommendations.push('⛔ Diese Website NICHT besuchen!')
    recommendations.push('⛔ KEINE persönlichen Daten eingeben!')
    recommendations.push('⛔ KEINE Dateien herunterladen!')
  } else if (result.status === 'suspicious') {
    recommendations.push('⚠️ Vorsicht beim Besuch dieser Website')
    recommendations.push('⚠️ Überprüfen Sie die URL auf Rechtschreibfehler')
    if (result.contentAnalysis.hasLoginForm) {
      recommendations.push('⚠️ Geben Sie keine Login-Daten ein, es sei denn Sie sind sicher')
    }
  }
  
  if (!result.ssl) {
    recommendations.push('🔐 Die Verbindung ist nicht verschlüsselt (kein HTTPS)')
  }
  
  if (result.contentAnalysis.hasExternalScripts) {
    recommendations.push('📜 Die Website lädt externe Scripts von Drittanbietern')
  }
  
  if (result.contentAnalysis.iframeCount > 0) {
    recommendations.push('🖼️ Die Website enthält IFrames - überprüfen Sie die Quellen')
  }
  
  if (result.status === 'safe') {
    recommendations.push('✅ Die Website erscheint sicher')
    recommendations.push('✅ Bleiben Sie auf der Hauptdomain')
  }
  
  return recommendations
}

export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json()
    
    if (!url) {
      return NextResponse.json({ error: 'Keine URL angegeben' }, { status: 400 })
    }
    
    // Validate URL format
    let validUrl = url
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      validUrl = 'https://' + url
    }
    
    const parsedUrl = parseUrl(validUrl)
    if (!parsedUrl) {
      return NextResponse.json({ error: 'Ungültige URL-Format' }, { status: 400 })
    }
    
    // Initialize threats array with URL pattern analysis
    const threats: URLThreat[] = analyzeUrlPatterns(validUrl)
    
    // Check SSL
    const ssl = validUrl.startsWith('https://')
    if (!ssl) {
      threats.push({
        type: 'Warning',
        severity: 'medium',
        description: 'Keine verschlüsselte Verbindung (HTTP statt HTTPS)',
        location: 'Protocol'
      })
    }
    
    // Fetch page content using web-reader
    let pageContent = ''
    let title = ''
    let finalUrl = validUrl
    let fetchSuccess = false
    
    try {
      const zai = await ZAI.create()
      const result = await zai.functions.invoke('page_reader', { url: validUrl })
      
      if (result && result.data) {
        pageContent = result.data.html || ''
        title = result.data.title || ''
        finalUrl = result.data.url || validUrl
        fetchSuccess = true
      }
    } catch (fetchError) {
      console.error('Failed to fetch page:', fetchError)
      // Continue with URL-only analysis
    }
    
    // Analyze content if fetched successfully
    let contentAnalysis: URLScanResult['contentAnalysis'] = {
      hasLoginForm: false,
      hasPasswordField: false,
      hasDownloadButton: false,
      hasExternalScripts: false,
      scriptCount: 0,
      iframeCount: 0
    }
    
    if (fetchSuccess && pageContent) {
      const contentResult = analyzeContent(pageContent)
      threats.push(...contentResult.threats)
      contentAnalysis = contentResult.contentAnalysis
    }
    
    // Calculate threat level
    const threatLevel = calculateThreatLevel(threats)
    
    // Determine status
    let status: 'safe' | 'suspicious' | 'malicious'
    if (threatLevel >= 50 || threats.some(t => t.severity === 'critical')) {
      status = 'malicious'
    } else if (threatLevel >= 20 || threats.some(t => t.severity === 'high')) {
      status = 'suspicious'
    } else {
      status = 'safe'
    }
    
    // Check for redirects
    const redirects = finalUrl !== validUrl ? 1 : 0
    
    // Build result
    const result: URLScanResult = {
      url: validUrl,
      finalUrl,
      title,
      status,
      threatLevel,
      threats: threats.slice(0, 20), // Limit threats
      ssl,
      domainAge: 'Unbekannt',
      redirects,
      contentAnalysis,
      recommendations: []
    }
    
    // Generate recommendations
    result.recommendations = generateRecommendations(result)
    
    return NextResponse.json(result)
    
  } catch (error) {
    console.error('URL scan error:', error)
    return NextResponse.json({ 
      error: 'URL-Scan fehlgeschlagen: ' + (error instanceof Error ? error.message : 'Unbekannter Fehler')
    }, { status: 500 })
  }
}
