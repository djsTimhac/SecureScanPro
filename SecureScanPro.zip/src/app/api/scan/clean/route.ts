import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Patterns that should be removed from files
const REMOVABLE_PATTERNS = [
  // Scripts that should be removed
  { pattern: /<script[^>]*>[\s\S]*?alert\s*\(\s*["']Virus[^)]*\)[\s\S]*?<\/script>/gi, replacement: '', name: 'Fake Virus Alert Script' },
  { pattern: /<script[^>]*>[\s\S]*?alert\s*\(\s*["']Your computer[^)]*\)[\s\S]*?<\/script>/gi, replacement: '', name: 'Fake System Alert Script' },
  { pattern: /<script[^>]*>[\s\S]*?alert\s*\(\s*["']Windows Defender[^)]*\)[\s\S]*?<\/script>/gi, replacement: '', name: 'Fake Defender Alert' },
  { pattern: /<script[^>]*>[\s\S]*?Your PC is infected[\s\S]*?<\/script>/gi, replacement: '', name: 'Fake Infection Script' },
  
  // Notification abuse
  { pattern: /Notification\.requestPermission\s*\(\s*\)/g, replacement: '// Notification permission removed by SecureScan', name: 'Auto Notification Request' },
  { pattern: /new\s+Notification\s*\([^)]*\)/g, replacement: '/* Notification blocked by SecureScan */', name: 'Desktop Notification' },
  
  // Malicious eval
  { pattern: /eval\s*\(\s*String\.fromCharCode/gi, replacement: '/* Blocked malicious eval */', name: 'Obfuscated Eval' },
  { pattern: /eval\s*\(\s*atob\s*\(/gi, replacement: '/* Blocked base64 eval */', name: 'Base64 Eval' },
  
  // XSS patterns
  { pattern: /onerror\s*=\s*["']?\s*alert\s*\(/gi, replacement: 'data-blocked="SecureScan"', name: 'Error Handler XSS' },
  { pattern: /onload\s*=\s*["']?\s*alert\s*\(/gi, replacement: 'data-blocked="SecureScan"', name: 'Load Handler XSS' },
  
  // Shell commands
  { pattern: /shell_exec\s*\([^)]*\)/g, replacement: '/* shell_exec blocked */', name: 'Shell Exec' },
  { pattern: /system\s*\(\s*["'][^"']*["']\s*\)/g, replacement: '/* system blocked */', name: 'System Command' },
  { pattern: /passthru\s*\([^)]*\)/g, replacement: '/* passthru blocked */', name: 'Passthru' },
  
  // EICAR test
  { pattern: /X5O!P%@AP\[4\\PZX54\\(P\^\)7CC\)7\}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H\+H\*/gi, replacement: '[EICAR REMOVED BY SECURESCAN]', name: 'EICAR Test File' },
  
  // Tech support scam patterns
  { pattern: /Call\s+(Microsoft|Apple|Windows|Dell|HP)\s+Support[^<]*/gi, replacement: '[TECH SUPPORT SCAM REMOVED]', name: 'Tech Support Scam' },
  { pattern: /Your\s+(computer|PC|system)\s+is\s+infected[^<]*/gi, replacement: '[FAKE WARNING REMOVED]', name: 'Fake Infection Warning' },
  
  // Phishing patterns
  { pattern: /paypal\.com\.verify[^\s"']*/gi, replacement: '[PHISHING URL REMOVED]', name: 'PayPal Phishing' },
  { pattern: /amazon\.com\.secure[^\s"']*/gi, replacement: '[PHISHING URL REMOVED]', name: 'Amazon Phishing' },
  
  // Auto-redirects
  { pattern: /window\.location\.replace\s*\([^)]*\)/g, replacement: '/* Auto-redirect blocked by SecureScan */', name: 'Auto Redirect' },
  
  // Cookie theft
  { pattern: /<script[^>]*>[\s\S]*?document\.cookie[\s\S]*?<\/script>/gi, replacement: '<!-- Cookie script removed by SecureScan -->', name: 'Cookie Theft Script' },
]

interface CleanResult {
  originalSize: number
  cleanedSize: number
  removedThreats: string[]
  remainingThreats: string[]
  cleanedContent: string
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      return NextResponse.json({ error: 'Keine Datei angegeben' }, { status: 400 })
    }
    
    // Read file content
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    let content = buffer.toString('utf-8')
    const originalSize = content.length
    
    const removedThreats: string[] = []
    const remainingThreats: string[] = []
    
    // Apply cleaning patterns
    for (const cleaner of REMOVABLE_PATTERNS) {
      const matches = content.match(cleaner.pattern)
      if (matches && matches.length > 0) {
        content = content.replace(cleaner.pattern, cleaner.replacement)
        removedThreats.push(`${cleaner.name} (${matches.length}x)`)
      }
    }
    
    // Additional cleaning for specific threat types
    // Remove inline event handlers that look malicious
    const maliciousHandlers = content.match(/on\w+\s*=\s*["']?\s*(eval|document\.cookie|alert|prompt|confirm)\s*\(/gi)
    if (maliciousHandlers) {
      content = content.replace(/on\w+\s*=\s*["']?\s*(eval|document\.cookie|alert|prompt|confirm)\s*\([^)]*\)/gi, 'data-blocked="SecureScan"')
      removedThreats.push(`Malicious Event Handlers (${maliciousHandlers.length}x)`)
    }
    
    // Remove suspicious iframes (often used for drive-by downloads)
    const suspiciousIframes = content.match(/<iframe[^>]*(hidden|display:\s*none|width:\s*0|height:\s*0)[^>]*>/gi)
    if (suspiciousIframes) {
      content = content.replace(/<iframe[^>]*(hidden|display:\s*none|width:\s*0|height:\s*0)[^>]*>[\s\S]*?<\/iframe>/gi, '<!-- Suspicious iframe removed by SecureScan -->')
      removedThreats.push(`Hidden IFrames (${suspiciousIframes.length}x)`)
    }
    
    // Remove base64 encoded scripts that look suspicious
    const base64Scripts = content.match(/<script[^>]*>[\s\S]*?atob\s*\([\s\S]*?<\/script>/gi)
    if (base64Scripts) {
      content = content.replace(/<script[^>]*>[\s\S]*?atob\s*\([\s\S]*?<\/script>/gi, '<!-- Base64 script removed by SecureScan -->')
      removedThreats.push(`Base64 Encoded Scripts (${base64Scripts.length}x)`)
    }
    
    // Remove inline styles that might hide malicious content
    const hiddenContent = content.match(/style\s*=\s*["'][^"']*(visibility:\s*hidden|display:\s*none|opacity:\s*0)[^"']*["']/gi)
    if (hiddenContent && hiddenContent.length > 3) {
      // Only flag if there are many hidden elements (might be suspicious)
      remainingThreats.push(`${hiddenContent.length} versteckte Elemente gefunden - manuelle Überprüfung empfohlen`)
    }
    
    const cleanedSize = content.length
    const bytesRemoved = originalSize - cleanedSize
    
    // Check if any remaining threats
    if (content.includes('eval(') || content.includes('exec(')) {
      remainingThreats.push('Einige verdächtige Muster könnten noch vorhanden sein')
    }
    
    // Calculate new threat level
    let newThreatLevel = 0
    if (removedThreats.length > 0) {
      newThreatLevel = Math.max(0, 20 - removedThreats.length * 5)
    }
    
    const cleanResult: CleanResult = {
      originalSize,
      cleanedSize,
      removedThreats,
      remainingThreats,
      cleanedContent: content
    }
    
    // Update database record if scanId provided
    const scanId = formData.get('scanId') as string
    if (scanId) {
      await db.scanResult.update({
        where: { id: scanId },
        data: {
          status: remainingThreats.length > 0 ? 'suspicious' : 'safe',
          threatLevel: newThreatLevel,
          scanDetails: JSON.stringify({
            cleaned: true,
            removedThreats,
            cleanedAt: new Date().toISOString()
          })
        }
      })
    }
    
    return NextResponse.json({
      success: true,
      fileName: file.name,
      bytesRemoved,
      removedThreats: removedThreats.length,
      threatNames: removedThreats,
      remainingThreats,
      newThreatLevel,
      cleanedFileBase64: Buffer.from(content).toString('base64')
    })
    
  } catch (error) {
    console.error('Clean error:', error)
    return NextResponse.json({ error: 'Reinigung fehlgeschlagen' }, { status: 500 })
  }
}
