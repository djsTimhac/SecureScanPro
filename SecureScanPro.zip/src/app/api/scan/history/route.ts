import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const history = await db.scanResult.findMany({
      orderBy: { scannedAt: 'desc' },
      take: 50
    })
    
    return NextResponse.json(history.map(item => ({
      id: item.id,
      fileName: item.fileName,
      fileSize: item.fileSize,
      status: item.status,
      threatLevel: item.threatLevel,
      scannedAt: item.scannedAt.toISOString()
    })))
  } catch (error) {
    console.error('Failed to fetch history:', error)
    return NextResponse.json({ error: 'Fehler beim Abrufen des Verlaufs' }, { status: 500 })
  }
}

export async function DELETE() {
  try {
    await db.scanResult.deleteMany()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Failed to clear history:', error)
    return NextResponse.json({ error: 'Fehler beim Löschen des Verlaufs' }, { status: 500 })
  }
}
