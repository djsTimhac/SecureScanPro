import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'
import path from 'path'

// File size limit: 50GB
const MAX_FILE_SIZE = 50 * 1024 * 1024 * 1024

// All script extensions for thorough scanning
const SCRIPT_EXTENSIONS = new Set([
  // JavaScript family
  '.js', '.mjs', '.cjs', '.ts', '.tsx', '.jsx', '.vue', '.svelte', '.coffee', '.litcoffee', '.ls',
  // Python
  '.py', '.pyw', '.pyc', '.pyd', '.pyo',
  // PHP
  '.php', '.phtml', '.php3', '.php4', '.php5', '.php7', '.phps', '.phar',
  // Ruby
  '.rb', '.rbw', '.rake', '.gemspec',
  // Perl
  '.pl', '.pm', '.t', '.pod',
  // Shell
  '.sh', '.bash', '.zsh', '.ksh', '.csh', '.tcsh', '.fish',
  // PowerShell
  '.ps1', '.ps2', '.psm1', '.psd1', '.psc1',
  // VBScript/Windows
  '.vbs', '.vbe', '.wsf', '.wsh', '.wsc', '.hta', '.bat', '.cmd', '.com',
  // Web
  '.asp', '.aspx', '.asax', '.ashx', '.asmx', '.svc', '.jsp', '.jspx', '.jspa', '.jspf', '.tag',
  // Other languages
  '.go', '.rs', '.dart', '.swift', '.kt', '.kts', '.scala', '.sc',
  '.clj', '.cljs', '.cljc', '.edn', '.ex', '.exs', '.erl', '.hrl',
  '.hs', '.lhs', '.ml', '.mli', '.fs', '.fsi', '.fsx', '.fsscript',
  '.lua', '.r', '.rmd', '.jl', '.nim', '.cr', '.d', '.di',
  '.sql', '.ddl', '.dml', '.plsql', '.tsql',
  '.groovy', '.gvy', '.gy', '.gsh',
  '.scm', '.ss', '.rkt', '.lisp', '.lsp', '.cl',
  '.asm', '.s', '.S',
  // Config/Data that can contain scripts
  '.json', '.yaml', '.yml', '.xml', '.toml', '.ini', '.cfg', '.conf',
  '.html', '.htm', '.xhtml', '.svg', '.xsl', '.xslt',
])

// Binary files that still need scanning
const SCAN_BINARY_EXTENSIONS = new Set([
  '.exe', '.dll', '.so', '.dylib', '.ocx', '.sys', '.drv',
  '.jar', '.war', '.ear', '.apk', '.dex', '.class',
  '.swf', '.fla',
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
  '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz',
  '.iso', '.img', '.dmg', '.pkg', '.deb', '.rpm',
  '.mp3', '.mp4', '.avi', '.mkv', '.mov', '.wav', '.flac',
  '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.ico', '.svg',
])

// ==================== COMPREHENSIVE DANGEROUS PATTERNS ====================

// All critical malware indicators
const CRITICAL_INDICATORS = [
  // EICAR test file
  { pattern: 'X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*', name: 'EICAR Test Virus', severity: 'critical' as const, category: 'test' },
  
  // Remote Access Trojans
  { pattern: 'mimikatz', name: 'Mimikatz - Credential Theft Tool', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'meterpreter', name: 'Metasploit Meterpreter', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'metasploit', name: 'Metasploit Framework', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'cobaltstrike', name: 'Cobalt Strike', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'beacon.exe', name: 'Cobalt Strike Beacon', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'darkcomet', name: 'DarkComet RAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'njrat', name: 'njRAT Remote Access Trojan', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'remcos', name: 'Remcos RAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'netwire', name: 'NetWire RAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'asyncrat', name: 'AsyncRAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'quasar', name: 'Quasar RAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'poisonivy', name: 'Poison Ivy RAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'gh0st', name: 'Gh0st RAT', severity: 'critical' as const, category: 'trojan' },
  { pattern: 'plagent', name: 'PlugX Trojan', severity: 'critical' as const, category: 'trojan' },
  
  // Ransomware indicators
  { pattern: 'ransomware', name: 'Ransomware Reference', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'encryptFiles', name: 'File Encryption (Ransomware)', severity: 'critical' as const, category: 'ransomware' },
  { pattern: '.encrypted', name: 'Encrypted File Extension', severity: 'critical' as const, category: 'ransomware' },
  { pattern: '.locked', name: 'Locked File Extension', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'wannacry', name: 'WannaCry Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'petya', name: 'Petya Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'notpetya', name: 'NotPetya Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'ryuk', name: 'Ryuk Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'sodinokibi', name: 'REvil Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'lockbit', name: 'LockBit Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'contibak', name: 'Conti Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'blackcat', name: 'BlackCat Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'alphv', name: 'ALPHV Ransomware', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'decrypt_', name: 'Decrypt Function', severity: 'high' as const, category: 'ransomware' },
  { pattern: 'encrypt_', name: 'Encrypt Function', severity: 'high' as const, category: 'ransomware' },
  { pattern: 'bitcoin address', name: 'Bitcoin Ransom', severity: 'high' as const, category: 'ransomware' },
  { pattern: 'pay ransom', name: 'Ransom Demand', severity: 'critical' as const, category: 'ransomware' },
  { pattern: 'your files are encrypted', name: 'Ransom Message', severity: 'critical' as const, category: 'ransomware' },
  
  // Crypto miners
  { pattern: 'coinhive', name: 'Coinhive Crypto Miner', severity: 'critical' as const, category: 'miner' },
  { pattern: 'minero.ccj', name: 'Minero Crypto Miner', severity: 'critical' as const, category: 'miner' },
  { pattern: 'crypto-miner', name: 'Crypto Miner', severity: 'critical' as const, category: 'miner' },
  { pattern: 'xmrig', name: 'XMRig Miner', severity: 'critical' as const, category: 'miner' },
  { pattern: 'stratum+tcp', name: 'Mining Pool Protocol', severity: 'critical' as const, category: 'miner' },
  { pattern: 'pool.minero', name: 'Mining Pool', severity: 'critical' as const, category: 'miner' },
  { pattern: 'hashrate', name: 'Hashrate Mining', severity: 'high' as const, category: 'miner' },
  { pattern: 'monero', name: 'Monero Mining Reference', severity: 'high' as const, category: 'miner' },
  
  // Reverse shells
  { pattern: 'reverse shell', name: 'Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'bind shell', name: 'Bind Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'netcat -e', name: 'Netcat Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'nc.exe -e', name: 'Netcat Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'nc -l -p', name: 'Netcat Listener', severity: 'high' as const, category: 'backdoor' },
  { pattern: '/bin/bash -i', name: 'Interactive Bash Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: '/bin/sh -i', name: 'Interactive Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'bash -i >&', name: 'Bash Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'python -c \'import socket', name: 'Python Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'perl -e \'use Socket', name: 'Perl Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'ruby -rsocket', name: 'Ruby Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'php -r \'$sock=fsockopen', name: 'PHP Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'socat TCP4', name: 'Socat Reverse Shell', severity: 'critical' as const, category: 'backdoor' },
  
  // Keyloggers
  { pattern: 'keylogger', name: 'Keylogger', severity: 'critical' as const, category: 'spyware' },
  { pattern: 'keylog', name: 'Keylogger Reference', severity: 'critical' as const, category: 'spyware' },
  { pattern: 'hook keyboard', name: 'Keyboard Hook', severity: 'critical' as const, category: 'spyware' },
  { pattern: 'setwindowshookex', name: 'Windows Hook', severity: 'critical' as const, category: 'spyware' },
  { pattern: 'getasynckeystate', name: 'Key State Monitor', severity: 'critical' as const, category: 'spyware' },
  { pattern: 'getkeystate', name: 'Key State Check', severity: 'high' as const, category: 'spyware' },
  { pattern: 'pynput.keyboard', name: 'Python Keyboard Monitor', severity: 'critical' as const, category: 'spyware' },
  { pattern: 'on_press(', name: 'Key Press Handler', severity: 'high' as const, category: 'spyware' },
  { pattern: 'onkeydown', name: 'Key Down Handler', severity: 'high' as const, category: 'spyware' },
  
  // Backdoors
  { pattern: 'backdoor', name: 'Backdoor', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'webshell', name: 'Web Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'c99shell', name: 'C99 Web Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'r57shell', name: 'R57 Web Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'b374k', name: 'B374k Web Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'wso shell', name: 'WSO Web Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'china chopper', name: 'China Chopper Web Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'alfa shell', name: 'Alfa Shell', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'passthru($_', name: 'PHP Backdoor', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'eval($_POST', name: 'PHP Backdoor', severity: 'critical' as const, category: 'backdoor' },
  { pattern: 'assert($_', name: 'PHP Backdoor', severity: 'critical' as const, category: 'backdoor' },
  
  // Rootkits
  { pattern: 'rootkit', name: 'Rootkit', severity: 'critical' as const, category: 'rootkit' },
  { pattern: 'kernel module', name: 'Kernel Module (Rootkit)', severity: 'high' as const, category: 'rootkit' },
  { pattern: 'loadable kernel module', name: 'Loadable Kernel Module', severity: 'high' as const, category: 'rootkit' },
  { pattern: 'syscall hook', name: 'Syscall Hooking', severity: 'critical' as const, category: 'rootkit' },
  { pattern: 'dkom', name: 'DKOM Rootkit', severity: 'critical' as const, category: 'rootkit' },
  { pattern: 'ssdt hook', name: 'SSDT Hooking', severity: 'critical' as const, category: 'rootkit' },
  
  // Exploits
  { pattern: 'exploit', name: 'Exploit Code', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'payload', name: 'Payload', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'buffer overflow', name: 'Buffer Overflow', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'heap overflow', name: 'Heap Overflow', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'stack overflow', name: 'Stack Overflow Exploit', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'format string', name: 'Format String Vulnerability', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'sql injection', name: 'SQL Injection', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'xss', name: 'Cross-Site Scripting', severity: 'high' as const, category: 'exploit' },
  { pattern: 'csrf', name: 'Cross-Site Request Forgery', severity: 'high' as const, category: 'exploit' },
  { pattern: 'rce', name: 'Remote Code Execution', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'lfi', name: 'Local File Inclusion', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'rfi', name: 'Remote File Inclusion', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'ssti', name: 'Server-Side Template Injection', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'xxe', name: 'XML External Entity', severity: 'critical' as const, category: 'exploit' },
  { pattern: 'ssrf', name: 'Server-Side Request Forgery', severity: 'high' as const, category: 'exploit' },
  
  // Botnets
  { pattern: 'botnet', name: 'Botnet', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'ddos', name: 'DDoS Attack', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'mirai', name: 'Mirai Botnet', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'mozi', name: 'Mozi Botnet', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'emotet', name: 'Emotet Botnet', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'trickbot', name: 'TrickBot', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'qakbot', name: 'QakBot', severity: 'critical' as const, category: 'botnet' },
  { pattern: 'icedid', name: 'IcedID', severity: 'critical' as const, category: 'botnet' },
  
  // Tech Support Scams
  { pattern: 'Your PC is infected', name: 'Fake Virus Alert', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Your computer is infected', name: 'Fake Virus Alert', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Windows has detected', name: 'Fake System Alert', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Microsoft has detected', name: 'Fake Microsoft Alert', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Call Microsoft', name: 'Tech Support Scam', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Call Apple Support', name: 'Apple Support Scam', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Call Windows', name: 'Windows Support Scam', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Toll-Free Technical Support', name: 'Tech Support Scam', severity: 'critical' as const, category: 'scam' },
  { pattern: 'Your system is at risk', name: 'Fake System Risk', severity: 'high' as const, category: 'scam' },
  { pattern: 'Immediate action required', name: 'Urgency Scam', severity: 'high' as const, category: 'scam' },
  { pattern: 'Your computer will be locked', name: 'Lock Screen Scam', severity: 'critical' as const, category: 'scam' },
  { pattern: 'virus detected', name: 'Fake Virus Detection', severity: 'high' as const, category: 'scam' },
  { pattern: 'suspicious activity detected', name: 'Fake Activity Alert', severity: 'high' as const, category: 'scam' },
  
  // Phishing
  { pattern: 'paypal.com.verify', name: 'PayPal Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'paypal.com.secure', name: 'PayPal Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'amazon.com.verify', name: 'Amazon Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'amazon.com.secure', name: 'Amazon Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'appleid.verify', name: 'Apple ID Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'icloud.com.verify', name: 'iCloud Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'google.com.verify', name: 'Google Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'gmail.com.verify', name: 'Gmail Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'facebook.com.verify', name: 'Facebook Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'microsoft.com.verify', name: 'Microsoft Phishing', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'banking-', name: 'Fake Banking Site', severity: 'critical' as const, category: 'phishing' },
  { pattern: '-secure-login', name: 'Fake Login Page', severity: 'critical' as const, category: 'phishing' },
  { pattern: 'verify your account', name: 'Account Verification Scam', severity: 'high' as const, category: 'phishing' },
  { pattern: 'confirm your identity', name: 'Identity Verification Scam', severity: 'high' as const, category: 'phishing' },
  { pattern: 'update your payment', name: 'Payment Scam', severity: 'high' as const, category: 'phishing' },
  { pattern: 'your account will be suspended', name: 'Account Suspension Scam', severity: 'high' as const, category: 'phishing' },
  { pattern: 'verify your email', name: 'Email Verification Scam', severity: 'medium' as const, category: 'phishing' },
  { pattern: 'password expired', name: 'Password Expiration Scam', severity: 'high' as const, category: 'phishing' },
  
  // Suspicious URLs
  { pattern: '.onion', name: 'Dark Web Link', severity: 'high' as const, category: 'suspicious' },
  { pattern: 'pastebin.com/raw', name: 'Pastebin Raw Content', severity: 'medium' as const, category: 'suspicious' },
  { pattern: 'ngrok.io', name: 'Ngrok Tunnel', severity: 'high' as const, category: 'suspicious' },
  { pattern: 'burpcollaborator', name: 'Burp Collaborator', severity: 'high' as const, category: 'suspicious' },
  { pattern: 'webhook.site', name: 'Webhook Site', severity: 'medium' as const, category: 'suspicious' },
  { pattern: 'requestbin', name: 'Request Bin', severity: 'medium' as const, category: 'suspicious' },
  { pattern: 'dnslog', name: 'DNS Log', severity: 'high' as const, category: 'suspicious' },
  { pattern: 'ceye.io', name: 'CEYE Monitor', severity: 'high' as const, category: 'suspicious' },
]

// Code execution patterns
const CODE_EXECUTION_PATTERNS = [
  // JavaScript/Node.js
  { pattern: 'eval(', name: 'eval() - Dynamic Code', severity: 'critical' as const },
  { pattern: 'Function(', name: 'Function() Constructor', severity: 'high' as const },
  { pattern: 'new Function(', name: 'new Function()', severity: 'high' as const },
  { pattern: 'constructor("return this")()', name: 'Sandbox Escape', severity: 'critical' as const },
  { pattern: 'constructor.constructor(', name: 'Sandbox Escape', severity: 'critical' as const },
  { pattern: 'setTimeout([', name: 'setTimeout with String', severity: 'high' as const },
  { pattern: 'setInterval([', name: 'setInterval with String', severity: 'high' as const },
  { pattern: 'setImmediate([', name: 'setImmediate with String', severity: 'high' as const },
  { pattern: 'vm.runInContext', name: 'VM Code Execution', severity: 'critical' as const },
  { pattern: 'vm.runInNewContext', name: 'VM Code Execution', severity: 'critical' as const },
  { pattern: 'vm.runInThisContext', name: 'VM Code Execution', severity: 'critical' as const },
  { pattern: 'vm.compileFunction', name: 'VM Compilation', severity: 'high' as const },
  { pattern: 'script.runInNewContext', name: 'Script Execution', severity: 'critical' as const },
  
  // Python
  { pattern: 'exec(', name: 'exec() - Code Execution', severity: 'critical' as const },
  { pattern: 'eval(', name: 'eval() - Code Execution', severity: 'critical' as const },
  { pattern: 'compile(', name: 'compile() - Code Compilation', severity: 'high' as const },
  { pattern: '__import__(', name: 'Dynamic Import', severity: 'high' as const },
  { pattern: 'importlib.import_module', name: 'Dynamic Module Import', severity: 'medium' as const },
  { pattern: 'execfile(', name: 'execfile() (Python 2)', severity: 'critical' as const },
  { pattern: 'execvp(', name: 'Execute Program', severity: 'critical' as const },
  { pattern: 'execvpe(', name: 'Execute Program', severity: 'critical' as const },
  { pattern: 'spawnl(', name: 'Spawn Process', severity: 'high' as const },
  { pattern: 'spawnle(', name: 'Spawn Process', severity: 'high' as const },
  { pattern: 'spawnlp(', name: 'Spawn Process', severity: 'high' as const },
  { pattern: 'spawnv(', name: 'Spawn Process', severity: 'high' as const },
  { pattern: 'spawnve(', name: 'Spawn Process', severity: 'high' as const },
  
  // PHP
  { pattern: 'eval(', name: 'eval() - Code Execution', severity: 'critical' as const },
  { pattern: 'assert(', name: 'assert() - Code Execution', severity: 'critical' as const },
  { pattern: 'create_function(', name: 'create_function()', severity: 'critical' as const },
  { pattern: 'preg_replace("/e"', name: 'preg_replace /e Modifier', severity: 'critical' as const },
  { pattern: "preg_replace('/e'", name: 'preg_replace /e Modifier', severity: 'critical' as const },
  { pattern: 'assert_options(', name: 'assert Configuration', severity: 'high' as const },
  { pattern: 'call_user_func(', name: 'Dynamic Function Call', severity: 'high' as const },
  { pattern: 'call_user_func_array(', name: 'Dynamic Function Call', severity: 'high' as const },
  { pattern: 'forward_static_call(', name: 'Static Method Call', severity: 'medium' as const },
  
  // PowerShell
  { pattern: 'Invoke-Expression', name: 'Invoke-Expression', severity: 'critical' as const },
  { pattern: ' IEX ', name: 'IEX Alias', severity: 'critical' as const },
  { pattern: 'IEX(', name: 'IEX Function', severity: 'critical' as const },
  { pattern: 'Invoke-Command', name: 'Remote Command', severity: 'high' as const },
  { pattern: 'Invoke-WebRequest', name: 'Web Request', severity: 'medium' as const },
  { pattern: 'Start-Job', name: 'Background Job', severity: 'medium' as const },
  { pattern: '& "', name: 'Call Operator', severity: 'medium' as const },
  { pattern: '. "', name: 'Dot Source', severity: 'medium' as const },
  
  // VBScript
  { pattern: 'Eval(', name: 'Eval Function', severity: 'critical' as const },
  { pattern: 'Execute(', name: 'Execute Statement', severity: 'critical' as const },
  { pattern: 'ExecuteGlobal', name: 'Execute Global', severity: 'critical' as const },
  { pattern: 'Exec(', name: 'Exec Method', severity: 'critical' as const },
  { pattern: 'Run(', name: 'Run Method', severity: 'high' as const },
]

// Command execution patterns
const COMMAND_EXECUTION_PATTERNS = [
  // Unix/Linux
  { pattern: 'os.system(', name: 'System Command', severity: 'critical' as const },
  { pattern: 'os.popen(', name: 'Pipe Open', severity: 'critical' as const },
  { pattern: 'subprocess.call(', name: 'Subprocess Call', severity: 'high' as const },
  { pattern: 'subprocess.run(', name: 'Subprocess Run', severity: 'high' as const },
  { pattern: 'subprocess.Popen(', name: 'Subprocess Popen', severity: 'high' as const },
  { pattern: 'commands.getoutput', name: 'Command Output', severity: 'high' as const },
  { pattern: 'popen(', name: 'Popen', severity: 'high' as const },
  { pattern: 'pclose(', name: 'Pclose', severity: 'medium' as const },
  
  // PHP
  { pattern: 'system(', name: 'system()', severity: 'critical' as const },
  { pattern: 'exec(', name: 'exec()', severity: 'critical' as const },
  { pattern: 'shell_exec(', name: 'shell_exec()', severity: 'critical' as const },
  { pattern: 'passthru(', name: 'passthru()', severity: 'critical' as const },
  { pattern: 'popen(', name: 'popen()', severity: 'high' as const },
  { pattern: 'proc_open(', name: 'proc_open()', severity: 'high' as const },
  { pattern: 'pcntl_exec(', name: 'pcntl_exec()', severity: 'critical' as const },
  { pattern: '`', name: 'Backtick Operator', severity: 'critical' as const },
  
  // JavaScript/Node
  { pattern: 'child_process.exec(', name: 'Child Process Exec', severity: 'critical' as const },
  { pattern: 'child_process.spawn(', name: 'Child Process Spawn', severity: 'critical' as const },
  { pattern: 'child_process.execSync(', name: 'Sync Exec', severity: 'critical' as const },
  { pattern: 'child_process.spawnSync(', name: 'Sync Spawn', severity: 'critical' as const },
  { pattern: 'child_process.execFile(', name: 'Exec File', severity: 'critical' as const },
  { pattern: 'child_process.fork(', name: 'Fork Process', severity: 'high' as const },
  { pattern: 'require("child_process")', name: 'Child Process Import', severity: 'high' as const },
  { pattern: "require('child_process')", name: 'Child Process Import', severity: 'high' as const },
  
  // Shell
  { pattern: 'rm -rf', name: 'rm -rf', severity: 'critical' as const },
  { pattern: 'rm -r', name: 'rm -r', severity: 'critical' as const },
  { pattern: 'rm -f', name: 'rm -f', severity: 'high' as const },
  { pattern: 'dd if=', name: 'dd Command', severity: 'critical' as const },
  { pattern: 'mkfs.', name: 'Format Filesystem', severity: 'critical' as const },
  { pattern: 'fdisk', name: 'Disk Partition', severity: 'critical' as const },
  { pattern: 'chmod 777', name: 'Full Permissions', severity: 'high' as const },
  { pattern: 'chmod +x', name: 'Make Executable', severity: 'medium' as const },
  { pattern: 'chown ', name: 'Change Owner', severity: 'high' as const },
  { pattern: 'sudo ', name: 'Sudo Command', severity: 'high' as const },
  { pattern: 'su ', name: 'Switch User', severity: 'high' as const },
  { pattern: 'kill -9', name: 'Force Kill', severity: 'high' as const },
  { pattern: 'killall ', name: 'Kill All', severity: 'high' as const },
  
  // Network commands
  { pattern: 'wget ', name: 'wget Download', severity: 'medium' as const },
  { pattern: 'curl ', name: 'curl Download', severity: 'medium' as const },
  { pattern: 'nc -', name: 'Netcat', severity: 'critical' as const },
  { pattern: 'ncat ', name: 'Ncat', severity: 'critical' as const },
  { pattern: 'telnet ', name: 'Telnet', severity: 'medium' as const },
  { pattern: 'ssh ', name: 'SSH', severity: 'medium' as const },
  { pattern: 'scp ', name: 'SCP', severity: 'medium' as const },
  { pattern: 'rsync ', name: 'Rsync', severity: 'medium' as const },
  { pattern: 'ftp ', name: 'FTP', severity: 'medium' as const },
]

// Obfuscation patterns
const OBFUSCATION_PATTERNS = [
  // Base64
  { pattern: 'atob(', name: 'Base64 Decode', severity: 'high' as const },
  { pattern: 'btoa(', name: 'Base64 Encode', severity: 'medium' as const },
  { pattern: 'base64_decode(', name: 'Base64 Decode', severity: 'high' as const },
  { pattern: 'base64_encode(', name: 'Base64 Encode', severity: 'medium' as const },
  { pattern: 'base64.b64decode', name: 'Base64 Decode', severity: 'high' as const },
  { pattern: 'base64.b64encode', name: 'Base64 Encode', severity: 'medium' as const },
  { pattern: 'FromBase64String', name: 'Base64 Decode', severity: 'high' as const },
  { pattern: 'ToBase64String', name: 'Base64 Encode', severity: 'medium' as const },
  
  // Character encoding
  { pattern: 'String.fromCharCode(', name: 'Char Code Encoding', severity: 'critical' as const },
  { pattern: 'charCodeAt(', name: 'Char Code Access', severity: 'medium' as const },
  { pattern: 'chr(', name: 'Character Conversion', severity: 'high' as const },
  { pattern: 'ord(', name: 'Ordinal Value', severity: 'medium' as const },
  { pattern: 'String.fromCodePoint(', name: 'Unicode Code Point', severity: 'high' as const },
  
  // URL encoding
  { pattern: 'escape(', name: 'URL Escape', severity: 'medium' as const },
  { pattern: 'unescape(', name: 'URL Unescape', severity: 'high' as const },
  { pattern: 'encodeURI(', name: 'URI Encode', severity: 'low' as const },
  { pattern: 'decodeURI(', name: 'URI Decode', severity: 'medium' as const },
  { pattern: 'encodeURIComponent(', name: 'URI Component Encode', severity: 'low' as const },
  { pattern: 'decodeURIComponent(', name: 'URI Component Decode', severity: 'medium' as const },
  { pattern: 'urlencode(', name: 'URL Encode', severity: 'medium' as const },
  { pattern: 'urldecode(', name: 'URL Decode', severity: 'high' as const },
  { pattern: 'rawurlencode(', name: 'Raw URL Encode', severity: 'medium' as const },
  { pattern: 'rawurldecode(', name: 'Raw URL Decode', severity: 'high' as const },
  
  // Hex/Binary
  { pattern: '\\x', name: 'Hex Escape', severity: 'high' as const },
  { pattern: '\\u', name: 'Unicode Escape', severity: 'high' as const },
  { pattern: 'hex(', name: 'Hex Conversion', severity: 'medium' as const },
  { pattern: 'binascii', name: 'Binary/ASCII', severity: 'high' as const },
  { pattern: 'bytes.fromhex', name: 'Hex to Bytes', severity: 'high' as const },
  { pattern: 'bin(', name: 'Binary Conversion', severity: 'low' as const },
  { pattern: 'int(', name: 'Integer Conversion', severity: 'low' as const },
  
  // Compression
  { pattern: 'gzinflate(', name: 'Gzip Inflate', severity: 'critical' as const },
  { pattern: 'gzuncompress(', name: 'Gzip Uncompress', severity: 'critical' as const },
  { pattern: 'gzdecode(', name: 'Gzip Decode', severity: 'critical' as const },
  { pattern: 'gzdeflate(', name: 'Gzip Deflate', severity: 'medium' as const },
  { pattern: 'zlib.decompress', name: 'Zlib Decompress', severity: 'high' as const },
  { pattern: 'zlib.compress', name: 'Zlib Compress', severity: 'medium' as const },
  
  // ROT13
  { pattern: 'str_rot13(', name: 'ROT13 Encoding', severity: 'high' as const },
  
  // Other encodings
  { pattern: 'convert_uudecode(', name: 'UU Decode', severity: 'critical' as const },
  { pattern: 'convert_uuencode(', name: 'UU Encode', severity: 'medium' as const },
  { pattern: 'quoted_printable_decode', name: 'Quoted Printable Decode', severity: 'high' as const },
  { pattern: 'quoted_printable_encode', name: 'Quoted Printable Encode', severity: 'medium' as const },
  { pattern: 'codecs.decode', name: 'Codec Decode', severity: 'high' as const },
  { pattern: 'codecs.encode', name: 'Codec Encode', severity: 'medium' as const },
]

// Data exfiltration patterns
const DATA_EXFIL_PATTERNS = [
  // Cookies
  { pattern: 'document.cookie', name: 'Cookie Access', severity: 'high' as const },
  { pattern: '$_COOKIE', name: 'Cookie Variable', severity: 'high' as const },
  { pattern: 'getcookie(', name: 'Get Cookie', severity: 'high' as const },
  { pattern: 'setcookie(', name: 'Set Cookie', severity: 'medium' as const },
  
  // Storage
  { pattern: 'localStorage', name: 'Local Storage', severity: 'medium' as const },
  { pattern: 'sessionStorage', name: 'Session Storage', severity: 'medium' as const },
  { pattern: 'indexedDB', name: 'IndexedDB', severity: 'medium' as const },
  
  // Form data
  { pattern: '$_POST', name: 'POST Data', severity: 'medium' as const },
  { pattern: '$_GET', name: 'GET Data', severity: 'medium' as const },
  { pattern: '$_REQUEST', name: 'Request Data', severity: 'high' as const },
  { pattern: '$_FILES', name: 'File Upload', severity: 'medium' as const },
  { pattern: 'FormData(', name: 'Form Data', severity: 'medium' as const },
  
  // Sensitive data
  { pattern: 'password', name: 'Password Reference', severity: 'medium' as const },
  { pattern: 'credential', name: 'Credential Reference', severity: 'medium' as const },
  { pattern: 'secret', name: 'Secret Reference', severity: 'medium' as const },
  { pattern: 'api_key', name: 'API Key Reference', severity: 'high' as const },
  { pattern: 'apikey', name: 'API Key Reference', severity: 'high' as const },
  { pattern: 'token', name: 'Token Reference', severity: 'medium' as const },
  { pattern: 'private_key', name: 'Private Key Reference', severity: 'critical' as const },
  { pattern: 'privatekey', name: 'Private Key Reference', severity: 'critical' as const },
  
  // Environment
  { pattern: 'process.env', name: 'Environment Variables', severity: 'high' as const },
  { pattern: 'os.environ', name: 'Environment Variables', severity: 'high' as const },
  { pattern: 'getenv(', name: 'Get Environment', severity: 'high' as const },
  { pattern: 'putenv(', name: 'Set Environment', severity: 'critical' as const },
  { pattern: '$_SERVER', name: 'Server Variables', severity: 'medium' as const },
  { pattern: '$_ENV', name: 'Environment Variables', severity: 'medium' as const },
  
  // System info
  { pattern: 'phpinfo(', name: 'PHP Info', severity: 'high' as const },
  { pattern: 'phpversion(', name: 'PHP Version', severity: 'medium' as const },
  { pattern: 'uname(', name: 'System Info', severity: 'medium' as const },
  { pattern: 'gethostname(', name: 'Hostname', severity: 'low' as const },
  { pattern: 'get_current_user(', name: 'Current User', severity: 'medium' as const },
  { pattern: 'getcwd(', name: 'Current Directory', severity: 'low' as const },
  { pattern: '__dirname', name: 'Directory Name', severity: 'low' as const },
  { pattern: '__filename', name: 'File Name', severity: 'low' as const },
  
  // Privilege info
  { pattern: 'getuid(', name: 'User ID', severity: 'medium' as const },
  { pattern: 'geteuid(', name: 'Effective User ID', severity: 'medium' as const },
  { pattern: 'getgid(', name: 'Group ID', severity: 'medium' as const },
  { pattern: 'getegid(', name: 'Effective Group ID', severity: 'medium' as const },
  { pattern: 'whoami', name: 'Current User', severity: 'low' as const },
  { pattern: 'id ', name: 'User/Group IDs', severity: 'low' as const },
]

// Network patterns
const NETWORK_PATTERNS = [
  // HTTP requests
  { pattern: 'fetch(', name: 'Fetch Request', severity: 'medium' as const },
  { pattern: 'XMLHttpRequest', name: 'XHR Request', severity: 'medium' as const },
  { pattern: 'axios.', name: 'Axios Request', severity: 'low' as const },
  { pattern: 'http.request(', name: 'HTTP Request', severity: 'medium' as const },
  { pattern: 'https.request(', name: 'HTTPS Request', severity: 'medium' as const },
  { pattern: 'urllib.request', name: 'URL Request', severity: 'medium' as const },
  { pattern: 'requests.get(', name: 'HTTP GET', severity: 'low' as const },
  { pattern: 'requests.post(', name: 'HTTP POST', severity: 'low' as const },
  { pattern: 'curl_exec(', name: 'cURL Execute', severity: 'medium' as const },
  { pattern: 'curl_init(', name: 'cURL Init', severity: 'low' as const },
  
  // WebSockets
  { pattern: 'WebSocket(', name: 'WebSocket', severity: 'medium' as const },
  { pattern: 'socket.io', name: 'Socket.IO', severity: 'low' as const },
  { pattern: 'new WebSocket(', name: 'WebSocket Connection', severity: 'medium' as const },
  
  // Raw sockets
  { pattern: 'socket.socket(', name: 'Raw Socket', severity: 'high' as const },
  { pattern: 'socket(', name: 'Socket Create', severity: 'high' as const },
  { pattern: 'fsockopen(', name: 'Socket Open', severity: 'high' as const },
  { pattern: 'socket_create(', name: 'Socket Create', severity: 'high' as const },
  { pattern: 'socket_connect(', name: 'Socket Connect', severity: 'high' as const },
  { pattern: 'net.connect(', name: 'Net Connect', severity: 'high' as const },
  { pattern: 'net.createConnection(', name: 'Net Connection', severity: 'high' as const },
  
  // Server
  { pattern: 'http.createServer(', name: 'HTTP Server', severity: 'medium' as const },
  { pattern: 'express()', name: 'Express Server', severity: 'low' as const },
  { pattern: 'app.listen(', name: 'Server Listen', severity: 'low' as const },
  { pattern: 'server.listen(', name: 'Server Listen', severity: 'low' as const },
  
  // Network scanning
  { pattern: 'nmap', name: 'Network Scanner', severity: 'high' as const },
  { pattern: 'masscan', name: 'Mass Scanner', severity: 'critical' as const },
  { pattern: 'zmap', name: 'ZMap Scanner', severity: 'critical' as const },
]

// File system patterns
const FILESYSTEM_PATTERNS = [
  // Read
  { pattern: 'fs.readFile(', name: 'Read File', severity: 'medium' as const },
  { pattern: 'fs.readFileSync(', name: 'Read File Sync', severity: 'medium' as const },
  { pattern: 'readFile(', name: 'Read File', severity: 'medium' as const },
  { pattern: 'file_get_contents(', name: 'File Get Contents', severity: 'medium' as const },
  { pattern: 'fread(', name: 'File Read', severity: 'medium' as const },
  { pattern: 'fopen(', name: 'File Open', severity: 'low' as const },
  { pattern: 'open(', name: 'File Open', severity: 'low' as const },
  { pattern: 'with open(', name: 'Python File Open', severity: 'low' as const },
  
  // Write
  { pattern: 'fs.writeFile(', name: 'Write File', severity: 'medium' as const },
  { pattern: 'fs.writeFileSync(', name: 'Write File Sync', severity: 'medium' as const },
  { pattern: 'writeFile(', name: 'Write File', severity: 'medium' as const },
  { pattern: 'file_put_contents(', name: 'File Put Contents', severity: 'medium' as const },
  { pattern: 'fwrite(', name: 'File Write', severity: 'medium' as const },
  { pattern: 'fprintf(', name: 'File Print', severity: 'medium' as const },
  
  // Delete
  { pattern: 'fs.unlink(', name: 'Delete File', severity: 'high' as const },
  { pattern: 'fs.unlinkSync(', name: 'Delete File Sync', severity: 'high' as const },
  { pattern: 'unlink(', name: 'Delete File', severity: 'high' as const },
  { pattern: 'os.remove(', name: 'Remove File', severity: 'high' as const },
  { pattern: 'shutil.rmtree(', name: 'Remove Directory Tree', severity: 'critical' as const },
  { pattern: 'rmdir(', name: 'Remove Directory', severity: 'high' as const },
  
  // Directory
  { pattern: 'fs.mkdir(', name: 'Create Directory', severity: 'low' as const },
  { pattern: 'os.mkdir(', name: 'Create Directory', severity: 'low' as const },
  { pattern: 'mkdir(', name: 'Create Directory', severity: 'low' as const },
  { pattern: 'fs.rmdir(', name: 'Remove Directory', severity: 'medium' as const },
  
  // Rename/Move
  { pattern: 'fs.rename(', name: 'Rename File', severity: 'medium' as const },
  { pattern: 'os.rename(', name: 'Rename File', severity: 'medium' as const },
  { pattern: 'rename(', name: 'Rename', severity: 'medium' as const },
  { pattern: 'move(', name: 'Move File', severity: 'medium' as const },
  { pattern: 'shutil.move(', name: 'Move File', severity: 'medium' as const },
  { pattern: 'shutil.copy(', name: 'Copy File', severity: 'medium' as const },
  
  // File system access
  { pattern: 'require("fs")', name: 'File System Module', severity: 'medium' as const },
  { pattern: "require('fs')", name: 'File System Module', severity: 'medium' as const },
  { pattern: 'import fs', name: 'File System Import', severity: 'medium' as const },
  { pattern: 'import os', name: 'OS Import', severity: 'medium' as const },
  { pattern: 'import shutil', name: 'Shutil Import', severity: 'medium' as const },
  
  // Path traversal
  { pattern: '../', name: 'Path Traversal', severity: 'high' as const },
  { pattern: '..\\', name: 'Path Traversal', severity: 'high' as const },
  { pattern: '/etc/passwd', name: 'Password File Access', severity: 'critical' as const },
  { pattern: '/etc/shadow', name: 'Shadow File Access', severity: 'critical' as const },
  { pattern: '/etc/hosts', name: 'Hosts File Access', severity: 'high' as const },
  { pattern: 'c:\\windows\\', name: 'Windows Directory', severity: 'medium' as const },
  { pattern: 'c:\\users\\', name: 'Users Directory', severity: 'medium' as const },
]

// Dangerous file inclusions
const INCLUSION_PATTERNS = [
  { pattern: 'include(', name: 'File Include', severity: 'high' as const },
  { pattern: 'include_once(', name: 'File Include Once', severity: 'high' as const },
  { pattern: 'require(', name: 'File Require', severity: 'high' as const },
  { pattern: 'require_once(', name: 'File Require Once', severity: 'high' as const },
  { pattern: 'include_path', name: 'Include Path', severity: 'medium' as const },
  { pattern: 'auto_prepend_file', name: 'Auto Prepend', severity: 'critical' as const },
  { pattern: 'auto_append_file', name: 'Auto Append', severity: 'critical' as const },
  { pattern: 'allow_url_include', name: 'URL Include', severity: 'critical' as const },
]

// Database patterns
const DATABASE_PATTERNS = [
  { pattern: 'mysql_query(', name: 'MySQL Query (deprecated)', severity: 'high' as const },
  { pattern: 'mysqli_query(', name: 'MySQLi Query', severity: 'medium' as const },
  { pattern: 'pg_query(', name: 'PostgreSQL Query', severity: 'medium' as const },
  { pattern: 'sqlite_query(', name: 'SQLite Query', severity: 'medium' as const },
  { pattern: 'SELECT * FROM', name: 'SQL SELECT', severity: 'medium' as const },
  { pattern: 'INSERT INTO', name: 'SQL INSERT', severity: 'medium' as const },
  { pattern: 'UPDATE ', name: 'SQL UPDATE', severity: 'medium' as const },
  { pattern: 'DELETE FROM', name: 'SQL DELETE', severity: 'high' as const },
  { pattern: 'DROP TABLE', name: 'SQL DROP', severity: 'critical' as const },
  { pattern: 'DROP DATABASE', name: 'SQL DROP DATABASE', severity: 'critical' as const },
  { pattern: 'TRUNCATE TABLE', name: 'SQL TRUNCATE', severity: 'high' as const },
  { pattern: 'UNION SELECT', name: 'SQL UNION', severity: 'high' as const },
  { pattern: 'OR 1=1', name: 'SQL Injection Pattern', severity: 'critical' as const },
  { pattern: "OR '1'='1", name: 'SQL Injection Pattern', severity: 'critical' as const },
  { pattern: '--', name: 'SQL Comment', severity: 'medium' as const },
  { pattern: '; DROP', name: 'SQL Injection', severity: 'critical' as const },
  { pattern: 'EXEC(', name: 'SQL Exec', severity: 'high' as const },
  { pattern: 'EXECUTE(', name: 'SQL Execute', severity: 'high' as const },
  { pattern: 'sp_executesql', name: 'Dynamic SQL', severity: 'high' as const },
]

// XSS patterns
const XSS_PATTERNS = [
  { pattern: '<script>', name: 'Script Tag', severity: 'critical' as const },
  { pattern: '</script>', name: 'Script Tag Close', severity: 'high' as const },
  { pattern: 'javascript:', name: 'JavaScript Protocol', severity: 'critical' as const },
  { pattern: 'vbscript:', name: 'VBScript Protocol', severity: 'critical' as const },
  { pattern: 'onerror=', name: 'OnError Handler', severity: 'critical' as const },
  { pattern: 'onload=', name: 'OnLoad Handler', severity: 'high' as const },
  { pattern: 'onclick=', name: 'OnClick Handler', severity: 'medium' as const },
  { pattern: 'onmouseover=', name: 'OnMouseOver Handler', severity: 'high' as const },
  { pattern: 'onfocus=', name: 'OnFocus Handler', severity: 'medium' as const },
  { pattern: 'onblur=', name: 'OnBlur Handler', severity: 'medium' as const },
  { pattern: 'onkeyup=', name: 'OnKeyUp Handler', severity: 'medium' as const },
  { pattern: 'onkeydown=', name: 'OnKeyDown Handler', severity: 'medium' as const },
  { pattern: 'onsubmit=', name: 'OnSubmit Handler', severity: 'medium' as const },
  { pattern: 'onchange=', name: 'OnChange Handler', severity: 'medium' as const },
  { pattern: 'oninput=', name: 'OnInput Handler', severity: 'medium' as const },
  { pattern: 'innerHTML', name: 'InnerHTML (XSS Risk)', severity: 'critical' as const },
  { pattern: 'outerHTML', name: 'OuterHTML (XSS Risk)', severity: 'critical' as const },
  { pattern: 'document.write(', name: 'Document Write (XSS)', severity: 'critical' as const },
  { pattern: 'insertAdjacentHTML', name: 'Adjacent HTML', severity: 'high' as const },
  { pattern: 'createContextualFragment', name: 'Contextual Fragment', severity: 'high' as const },
  { pattern: '<iframe', name: 'IFrame Tag', severity: 'high' as const },
  { pattern: '<embed', name: 'Embed Tag', severity: 'high' as const },
  { pattern: '<object', name: 'Object Tag', severity: 'high' as const },
  { pattern: 'expression(', name: 'CSS Expression', severity: 'critical' as const },
  { pattern: 'behavior:', name: 'CSS Behavior', severity: 'high' as const },
  { pattern: '-moz-binding:', name: 'Mozilla Binding', severity: 'high' as const },
]

// Notification/Popup patterns
const NOTIFICATION_PATTERNS = [
  { pattern: 'Notification.requestPermission', name: 'Notification Permission Request', severity: 'high' as const },
  { pattern: 'new Notification(', name: 'Create Notification', severity: 'medium' as const },
  { pattern: 'showNotification(', name: 'Show Notification', severity: 'medium' as const },
  { pattern: 'pushManager.subscribe', name: 'Push Subscription', severity: 'medium' as const },
  { pattern: 'window.open(', name: 'Open Popup Window', severity: 'medium' as const },
  { pattern: 'window.alert(', name: 'Alert Dialog', severity: 'low' as const },
  { pattern: 'window.confirm(', name: 'Confirm Dialog', severity: 'low' as const },
  { pattern: 'window.prompt(', name: 'Prompt Dialog', severity: 'low' as const },
  { pattern: 'alert(', name: 'Alert', severity: 'low' as const },
  { pattern: 'confirm(', name: 'Confirm', severity: 'low' as const },
  { pattern: 'prompt(', name: 'Prompt', severity: 'low' as const },
]

// Redirect patterns
const REDIRECT_PATTERNS = [
  { pattern: 'window.location=', name: 'Location Redirect', severity: 'high' as const },
  { pattern: 'window.location.href=', name: 'Href Redirect', severity: 'high' as const },
  { pattern: 'window.location.replace(', name: 'Location Replace', severity: 'high' as const },
  { pattern: 'window.location.assign(', name: 'Location Assign', severity: 'medium' as const },
  { pattern: 'location.reload(', name: 'Page Reload', severity: 'low' as const },
  { pattern: 'document.location=', name: 'Document Location', severity: 'high' as const },
  { pattern: 'header("Location:', name: 'PHP Redirect', severity: 'high' as const },
  { pattern: "header('Location:", name: 'PHP Redirect', severity: 'high' as const },
  { pattern: 'response.redirect(', name: 'Response Redirect', severity: 'medium' as const },
  { pattern: 'header(', name: 'PHP Header', severity: 'medium' as const },
  { pattern: 'meta http-equiv="refresh"', name: 'Meta Refresh', severity: 'high' as const },
  { pattern: '<meta refresh', name: 'Meta Refresh', severity: 'high' as const },
]

// Privilege escalation patterns
const PRIVILEGE_PATTERNS = [
  { pattern: 'os.setuid(', name: 'Set User ID', severity: 'critical' as const },
  { pattern: 'os.setgid(', name: 'Set Group ID', severity: 'critical' as const },
  { pattern: 'os.seteuid(', name: 'Set Effective UID', severity: 'critical' as const },
  { pattern: 'os.setegid(', name: 'Set Effective GID', severity: 'critical' as const },
  { pattern: 'os.setreuid(', name: 'Set Real/Effective UID', severity: 'critical' as const },
  { pattern: 'os.setregid(', name: 'Set Real/Effective GID', severity: 'critical' as const },
  { pattern: 'setuid(', name: 'Set UID', severity: 'critical' as const },
  { pattern: 'setgid(', name: 'Set GID', severity: 'critical' as const },
  { pattern: 'chown(', name: 'Change Owner', severity: 'high' as const },
  { pattern: 'os.chown(', name: 'Change Owner', severity: 'high' as const },
  { pattern: 'os.chmod(', name: 'Change Mode', severity: 'high' as const },
  { pattern: 'chmod(', name: 'Change Permissions', severity: 'medium' as const },
  { pattern: 'sudo(', name: 'Sudo Function', severity: 'high' as const },
  { pattern: 'sudo.', name: 'Sudo Module', severity: 'high' as const },
]

// Serialization patterns
const SERIALIZATION_PATTERNS = [
  { pattern: 'pickle.loads(', name: 'Pickle Deserialize (RCE Risk)', severity: 'critical' as const },
  { pattern: 'pickle.load(', name: 'Pickle Load (RCE Risk)', severity: 'critical' as const },
  { pattern: 'pickle.dumps(', name: 'Pickle Serialize', severity: 'medium' as const },
  { pattern: 'pickle.dump(', name: 'Pickle Dump', severity: 'medium' as const },
  { pattern: 'marshal.loads(', name: 'Marshal Deserialize', severity: 'critical' as const },
  { pattern: 'marshal.load(', name: 'Marshal Load', severity: 'critical' as const },
  { pattern: 'unserialize(', name: 'PHP Unserialize (RCE Risk)', severity: 'critical' as const },
  { pattern: 'serialize(', name: 'PHP Serialize', severity: 'medium' as const },
  { pattern: 'yaml.load(', name: 'YAML Load (RCE Risk)', severity: 'critical' as const },
  { pattern: 'yaml.unsafe_load(', name: 'YAML Unsafe Load', severity: 'critical' as const },
  { pattern: 'json.loads(', name: 'JSON Parse', severity: 'low' as const },
  { pattern: 'JSON.parse(', name: 'JSON Parse', severity: 'low' as const },
  { pattern: 'json_decode(', name: 'JSON Decode', severity: 'low' as const },
  { pattern: 'json_encode(', name: 'JSON Encode', severity: 'low' as const },
]

// Reflection/Introspection patterns
const REFLECTION_PATTERNS = [
  { pattern: 'getattr(', name: 'Get Attribute', severity: 'medium' as const },
  { pattern: 'setattr(', name: 'Set Attribute', severity: 'medium' as const },
  { pattern: 'delattr(', name: 'Delete Attribute', severity: 'medium' as const },
  { pattern: 'hasattr(', name: 'Has Attribute', severity: 'low' as const },
  { pattern: '__getattribute__', name: 'GetAttribute Override', severity: 'high' as const },
  { pattern: '__setattr__', name: 'SetAttr Override', severity: 'high' as const },
  { pattern: '__delattr__', name: 'DelAttr Override', severity: 'high' as const },
  { pattern: '__getattr__', name: 'GetAttr Magic Method', severity: 'medium' as const },
  { pattern: 'vars(', name: 'Get Object Vars', severity: 'low' as const },
  { pattern: 'dir(', name: 'List Attributes', severity: 'low' as const },
  { pattern: 'globals()', name: 'Global Variables', severity: 'medium' as const },
  { pattern: 'locals()', name: 'Local Variables', severity: 'medium' as const },
  { pattern: 'type(', name: 'Get Type', severity: 'low' as const },
  { pattern: 'isinstance(', name: 'Instance Check', severity: 'low' as const },
  { pattern: 'issubclass(', name: 'Subclass Check', severity: 'low' as const },
  { pattern: 'ReflectionClass', name: 'PHP Reflection', severity: 'medium' as const },
  { pattern: 'ReflectionMethod', name: 'Method Reflection', severity: 'medium' as const },
  { pattern: 'ReflectionProperty', name: 'Property Reflection', severity: 'medium' as const },
]

// Cryptography patterns
const CRYPTO_PATTERNS = [
  { pattern: 'hashlib.md5', name: 'MD5 Hash (Weak)', severity: 'medium' as const },
  { pattern: 'hashlib.sha1', name: 'SHA1 Hash (Weak)', severity: 'medium' as const },
  { pattern: 'MD5(', name: 'MD5 Function', severity: 'medium' as const },
  { pattern: 'SHA1(', name: 'SHA1 Function', severity: 'medium' as const },
  { pattern: 'crc32(', name: 'CRC32 Checksum', severity: 'low' as const },
  { pattern: 'from Crypto', name: 'PyCrypto Library', severity: 'medium' as const },
  { pattern: 'from cryptography', name: 'Cryptography Library', severity: 'medium' as const },
  { pattern: 'AES.new(', name: 'AES Encryption', severity: 'medium' as const },
  { pattern: 'RSA.generate(', name: 'RSA Key Generation', severity: 'medium' as const },
  { pattern: 'Crypto.Cipher', name: 'Crypto Cipher', severity: 'medium' as const },
  { pattern: 'mcrypt_encrypt', name: 'Mcrypt Encrypt (deprecated)', severity: 'medium' as const },
  { pattern: 'mcrypt_decrypt', name: 'Mcrypt Decrypt (deprecated)', severity: 'medium' as const },
  { pattern: 'openssl_encrypt', name: 'OpenSSL Encrypt', severity: 'medium' as const },
  { pattern: 'openssl_decrypt', name: 'OpenSSL Decrypt', severity: 'medium' as const },
]

// Registry patterns (Windows)
const REGISTRY_PATTERNS = [
  { pattern: 'HKEY_LOCAL_MACHINE', name: 'HKLM Registry', severity: 'high' as const },
  { pattern: 'HKEY_CURRENT_USER', name: 'HKCU Registry', severity: 'medium' as const },
  { pattern: 'HKEY_CLASSES_ROOT', name: 'HKCR Registry', severity: 'high' as const },
  { pattern: 'HKEY_USERS', name: 'HKU Registry', severity: 'high' as const },
  { pattern: 'RegOpenKey', name: 'Registry Open', severity: 'high' as const },
  { pattern: 'RegCreateKey', name: 'Registry Create', severity: 'critical' as const },
  { pattern: 'RegSetValue', name: 'Registry Set', severity: 'critical' as const },
  { pattern: 'RegDeleteKey', name: 'Registry Delete', severity: 'critical' as const },
  { pattern: 'RegDeleteValue', name: 'Registry Value Delete', severity: 'critical' as const },
  { pattern: 'HKLM:\\\\', name: 'PowerShell HKLM', severity: 'high' as const },
  { pattern: 'HKCU:\\\\', name: 'PowerShell HKCU', severity: 'medium' as const },
  { pattern: 'CurrentVersion\\\\Run', name: 'Startup Registry', severity: 'critical' as const },
  { pattern: 'Winlogon\\\\Shell', name: 'Shell Registry', severity: 'critical' as const },
  { pattern: 'Image File Execution', name: 'IFEO Registry', severity: 'critical' as const },
]

// Scheduled task patterns
const SCHEDULE_PATTERNS = [
  { pattern: 'crontab', name: 'Crontab', severity: 'high' as const },
  { pattern: '/etc/cron', name: 'Cron Directory', severity: 'high' as const },
  { pattern: '/etc/cron.d', name: 'Cron.d Directory', severity: 'high' as const },
  { pattern: '/etc/cron.daily', name: 'Daily Cron', severity: 'high' as const },
  { pattern: 'schtasks', name: 'Scheduled Tasks', severity: 'high' as const },
  { pattern: 'Task Scheduler', name: 'Task Scheduler', severity: 'medium' as const },
  { pattern: 'systemctl enable', name: 'Enable Service', severity: 'high' as const },
  { pattern: 'systemctl start', name: 'Start Service', severity: 'medium' as const },
  { pattern: 'service ', name: 'Service Command', severity: 'medium' as const },
  { pattern: 'launchctl', name: 'Launch Control (macOS)', severity: 'high' as const },
  { pattern: 'LaunchAgent', name: 'Launch Agent (macOS)', severity: 'high' as const },
  { pattern: 'LaunchDaemon', name: 'Launch Daemon (macOS)', severity: 'high' as const },
  { pattern: '/etc/init.d', name: 'Init Scripts', severity: 'high' as const },
  { pattern: 'rc.local', name: 'RC Local', severity: 'high' as const },
  { pattern: '/etc/rc', name: 'RC Scripts', severity: 'high' as const },
]

interface Threat {
  type: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  description: string
  location?: string
  removable: boolean
  line?: number
  category?: string
}

interface ScanDetails {
  entropy: number
  packedFiles: number
  suspiciousStrings: string[]
  networkIndicators: string[]
  registryModifications: string[]
  permissions: string[]
  fakeAlertsDetected: boolean
  notificationAbuse: boolean
  fileTypeCategory: string
  scanMode: string
  fileSizeCategory: string
  samplesAnalyzed: number
  scanTime: number
  scriptType: string
  totalPatterns: number
  linesScanned: number
  patternsChecked: number
  categoriesFound: string[]
}

function calculateEntropy(buffer: Buffer): number {
  if (buffer.length === 0) return 0
  const sampleRate = buffer.length > 100000 ? Math.floor(buffer.length / 50000) : 1
  const byteCounts = new Uint32Array(256)
  let samples = 0
  for (let i = 0; i < buffer.length; i += sampleRate) {
    byteCounts[buffer[i]]++
    samples++
  }
  let entropy = 0
  for (let i = 0; i < 256; i++) {
    if (byteCounts[i] > 0) {
      const probability = byteCounts[i] / samples
      entropy -= probability * Math.log2(probability)
    }
  }
  return entropy
}

function getScriptType(ext: string): string {
  const scriptTypes: Record<string, string> = {
    '.js': 'JavaScript', '.mjs': 'JavaScript (ES Module)', '.cjs': 'JavaScript (CommonJS)',
    '.ts': 'TypeScript', '.tsx': 'TypeScript (React)', '.jsx': 'JavaScript (React)',
    '.py': 'Python', '.pyw': 'Python (Windowed)', '.pyc': 'Python (Compiled)',
    '.php': 'PHP', '.phtml': 'PHP (HTML)',
    '.rb': 'Ruby', '.rbw': 'Ruby (Windowed)',
    '.pl': 'Perl', '.pm': 'Perl Module',
    '.sh': 'Shell Script', '.bash': 'Bash Script', '.zsh': 'Zsh Script',
    '.ps1': 'PowerShell', '.psm1': 'PowerShell Module',
    '.vbs': 'VBScript', '.vbe': 'VBScript (Encoded)',
    '.bat': 'Batch Script', '.cmd': 'Command Script',
    '.go': 'Go', '.rs': 'Rust', '.swift': 'Swift', '.dart': 'Dart',
    '.java': 'Java', '.kt': 'Kotlin', '.scala': 'Scala',
    '.lua': 'Lua', '.r': 'R', '.sql': 'SQL',
    '.html': 'HTML', '.htm': 'HTML', '.xhtml': 'XHTML',
    '.xml': 'XML', '.json': 'JSON', '.yaml': 'YAML', '.yml': 'YAML',
    '.css': 'CSS', '.scss': 'SCSS', '.less': 'LESS',
  }
  return scriptTypes[ext] || 'Unknown'
}

function getFileCategory(ext: string): string {
  if (SCRIPT_EXTENSIONS.has(ext)) return 'script'
  if (SCAN_BINARY_EXTENSIONS.has(ext)) return 'binary'
  return 'unknown'
}

function getFileSizeCategory(size: number): string {
  if (size < 1024) return 'Sehr Klein'
  if (size < 1024 * 1024) return 'Klein'
  if (size < 10 * 1024 * 1024) return 'Mittel'
  if (size < 100 * 1024 * 1024) return 'Groß'
  if (size < 500 * 1024 * 1024) return 'Sehr Groß'
  return 'Riesig'
}

function findLineNumber(content: string, pattern: string): number {
  const lines = content.split('\n')
  const patternLower = pattern.toLowerCase()
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].toLowerCase().includes(patternLower)) {
      return i + 1
    }
  }
  return 0
}

function analyzeAllPatterns(content: string, ext: string): {
  threats: Threat[]
  patternsChecked: number
  categoriesFound: Set<string>
} {
  const threats: Threat[] = []
  const contentLower = content.toLowerCase()
  const categoriesFound = new Set<string>()
  let patternsChecked = 0
  
  // Helper function to check patterns
  const checkPatterns = (patterns: typeof CRITICAL_INDICATORS, defaultCategory: string) => {
    for (const sig of patterns) {
      patternsChecked++
      const patternLower = sig.pattern.toLowerCase()
      if (contentLower.includes(patternLower)) {
        const line = findLineNumber(content, sig.pattern)
        const category = sig.category || defaultCategory
        categoriesFound.add(category)
        
        threats.push({
          type: sig.severity === 'critical' ? 'Critical' : 
                sig.severity === 'high' ? 'High Risk' : 
                sig.severity === 'medium' ? 'Warning' : 'Info',
          severity: sig.severity,
          description: sig.name,
          location: line > 0 ? `Zeile ${line}` : undefined,
          removable: false,
          line,
          category
        })
      }
    }
  }
  
  // Check ALL pattern categories
  checkPatterns(CRITICAL_INDICATORS, 'malware')
  checkPatterns(CODE_EXECUTION_PATTERNS, 'code_execution')
  checkPatterns(COMMAND_EXECUTION_PATTERNS, 'command_execution')
  checkPatterns(OBFUSCATION_PATTERNS, 'obfuscation')
  checkPatterns(DATA_EXFIL_PATTERNS, 'data_exfiltration')
  checkPatterns(NETWORK_PATTERNS, 'network')
  checkPatterns(FILESYSTEM_PATTERNS, 'filesystem')
  checkPatterns(INCLUSION_PATTERNS, 'inclusion')
  checkPatterns(DATABASE_PATTERNS, 'database')
  checkPatterns(XSS_PATTERNS, 'xss')
  checkPatterns(NOTIFICATION_PATTERNS, 'notification')
  checkPatterns(REDIRECT_PATTERNS, 'redirect')
  checkPatterns(PRIVILEGE_PATTERNS, 'privilege_escalation')
  checkPatterns(SERIALIZATION_PATTERNS, 'serialization')
  checkPatterns(REFLECTION_PATTERNS, 'reflection')
  checkPatterns(CRYPTO_PATTERNS, 'cryptography')
  checkPatterns(REGISTRY_PATTERNS, 'registry')
  checkPatterns(SCHEDULE_PATTERNS, 'persistence')
  
  // Remove duplicates (same description and line)
  const uniqueThreats: Threat[] = []
  const seen = new Set<string>()
  
  for (const threat of threats) {
    const key = `${threat.description}-${threat.line || 0}`
    if (!seen.has(key)) {
      seen.add(key)
      uniqueThreats.push(threat)
    }
  }
  
  // Sort by severity
  const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 }
  uniqueThreats.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity])
  
  return { threats: uniqueThreats, patternsChecked, categoriesFound }
}

// Binary file extensions that should NOT be scanned with text patterns
const BINARY_MEDIA_EXTENSIONS = new Set([
  // Images
  '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.ico', '.svg', '.tiff', '.tif', '.raw', '.heic', '.heif', '.avif',
  // Video
  '.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.mpeg', '.mpg', '.3gp', '.ogv',
  // Audio
  '.mp3', '.wav', '.flac', '.aac', '.ogg', '.wma', '.m4a', '.opus', '.aiff', '.ape',
  // Fonts
  '.ttf', '.otf', '.woff', '.woff2', '.eot',
  // Compressed (scan contents separately if needed)
  '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.zst',
  // Other binary
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.odt', '.ods', '.odp',
  '.sqlite', '.db', '.mdb', '.accdb',
  '.iso', '.img', '.dmg', '.pkg', '.deb', '.rpm',
])

function analyzeFile(buffer: Buffer, fileName: string, fullSize: number): {
  threats: Threat[]
  threatLevel: number
  scanDetails: ScanDetails
} {
  const startTime = Date.now()
  let threatScore = 0
  
  const ext = path.extname(fileName).toLowerCase()
  const fileCategory = getFileCategory(ext)
  const isScript = SCRIPT_EXTENSIONS.has(ext)
  const isBinaryMedia = BINARY_MEDIA_EXTENSIONS.has(ext)
  const scriptType = isScript ? getScriptType(ext) : ''
  
  // Calculate entropy
  const entropy = calculateEntropy(buffer)
  
  // Convert buffer to string for analysis
  let content: string
  try {
    content = buffer.toString('utf8')
  } catch {
    content = buffer.toString('latin1')
  }
  const linesScanned = content.split('\n').length
  
  let threats: Threat[] = []
  let patternsChecked = 0
  const categoriesFound = new Set<string>()
  
  // BINARY FILES: Only check for critical malware signatures, NOT code patterns
  if (isBinaryMedia) {
    // For binary/media files, only check CRITICAL malware indicators
    const contentLower = content.toLowerCase()
    
    for (const sig of CRITICAL_INDICATORS) {
      patternsChecked++
      if (contentLower.includes(sig.pattern.toLowerCase())) {
        const category = sig.category || 'malware'
        categoriesFound.add(category)
        
        threats.push({
          type: sig.severity === 'critical' ? 'Critical' : 'High Risk',
          severity: sig.severity,
          description: sig.name,
          category
        })
      }
    }
  } else {
    // TEXT/SCRIPT FILES: Full pattern analysis
    const result = analyzeAllPatterns(content, ext)
    threats = result.threats
    patternsChecked = result.patternsChecked
    result.categoriesFound.forEach(c => categoriesFound.add(c))
  }
  
  // Calculate threat score
  for (const threat of threats) {
    switch (threat.severity) {
      case 'critical': threatScore += 25; break
      case 'high': threatScore += 15; break
      case 'medium': threatScore += 8; break
      case 'low': threatScore += 3; break
    }
  }
  
  // Additional entropy check only for scripts
  if (entropy > 7.0 && isScript && !isBinaryMedia) {
    threats.push({
      type: 'Warning',
      severity: 'high',
      description: 'Hohe Entropie - möglicherweise obfusziert/verschlüsselt',
      category: 'obfuscation'
    })
    threatScore += 15
    categoriesFound.add('obfuscation')
  }
  
  // Extract URLs for network indicators (only for non-binary files)
  const networkIndicators = isBinaryMedia ? [] : 
    (content.match(/https?:\/\/[^\s<>"']+/gi) || []).slice(0, 10).map(u => u.substring(0, 60))
  
  const scanTime = Date.now() - startTime
  
  return {
    threats,
    threatLevel: Math.min(100, threatScore),
    scanDetails: {
      entropy,
      packedFiles: 0,
      suspiciousStrings: [],
      networkIndicators,
      registryModifications: [],
      permissions: [],
      fakeAlertsDetected: threats.some(t => t.category === 'scam'),
      notificationAbuse: !isBinaryMedia && content.toLowerCase().includes('notification.requestpermission'),
      fileTypeCategory: fileCategory,
      scanMode: '100% Vollständig',
      fileSizeCategory: getFileSizeCategory(fullSize),
      samplesAnalyzed: 1,
      scanTime,
      scriptType,
      totalPatterns: threats.length,
      linesScanned,
      patternsChecked,
      categoriesFound: Array.from(categoriesFound)
    }
  }
}

const contentLower = '' // Will be set in analyzeFile

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      return NextResponse.json({ error: 'Keine Datei angegeben' }, { status: 400 })
    }
    
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ 
        error: `Datei zu groß (max. 1GB). Ihre Datei: ${(file.size / 1024 / 1024 / 1024).toFixed(2)}GB` 
      }, { status: 400 })
    }
    
    // Read complete file
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    
    // Generate hash
    const hash = crypto.createHash('sha256').update(buffer).digest('hex')
    
    // Analyze file with 100% scan
    const { threats, threatLevel, scanDetails } = analyzeFile(buffer, file.name, file.size)
    
    // Determine status
    let status: 'safe' | 'suspicious' | 'malicious'
    if (threatLevel >= 50 || threats.some(t => t.severity === 'critical')) {
      status = 'malicious'
    } else if (threatLevel >= 20 || threats.some(t => t.severity === 'high')) {
      status = 'suspicious'
    } else {
      status = 'safe'
    }
    
    const canBeCleaned = threats.some(t => t.removable)
    
    // Save to database
    db.scanResult.create({
      data: {
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type || 'unknown',
        fileHash: hash,
        status,
        threatLevel,
        threats: JSON.stringify(threats),
        scanDetails: JSON.stringify(scanDetails)
      }
    }).catch(() => {})
    
    return NextResponse.json({
      id: Date.now().toString(),
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type || 'unknown',
      fileHash: hash,
      status,
      threatLevel,
      threats,
      scanDetails,
      canBeCleaned,
      scannedAt: new Date().toISOString()
    })
    
  } catch (error) {
    console.error('Scan error:', error)
    return NextResponse.json({ 
      error: 'Scan fehlgeschlagen: ' + (error instanceof Error ? error.message : 'Unbekannter Fehler')
    }, { status: 500 })
  }
}
