'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Shield, 
  ShieldAlert, 
  ShieldCheck, 
  ShieldX, 
  Upload, 
  FileText, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  FileSearch,
  Trash2,
  RefreshCw,
  AlertOctagon,
  BugPlay,
  Skull,
  AlertCircle,
  Download,
  Sparkles,
  Ban,
  Globe,
  Link,
  ExternalLink,
  Lock,
  LockOpen,
  FileCode,
  FolderOpen,
  Files,
  HardDrive,
  X,
  Plus,
  FolderPlus,
  Layers
} from 'lucide-react'
import { toast } from 'sonner'

interface Threat {
  type: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  description: string
  location?: string
  removable: boolean
  pattern?: string
  line?: number
  category?: string
}

interface Permission {
  name: string
  type: string
  risk: 'low' | 'medium' | 'high' | 'critical'
  description: string
  autoTrigger: boolean
}

interface ScanDetails {
  entropy: number
  packedFiles: number
  suspiciousStrings: string[]
  networkIndicators: string[]
  registryModifications: string[]
  permissions: Permission[]
  fakeAlertsDetected: boolean
  notificationAbuse: boolean
  fileTypeCategory?: string
  scanMode?: string
  fileSizeCategory?: string
  samplesAnalyzed?: number
  scanTime?: number
  scriptType?: string
  totalPatterns?: number
  linesScanned?: number
  patternsChecked?: number
  categoriesFound?: string[]
}

interface ScanResult {
  id: string
  fileName: string
  fileSize: number
  fileType: string
  fileHash: string
  status: 'safe' | 'suspicious' | 'malicious' | 'error' | 'scanning'
  threatLevel: number
  threats: Threat[]
  scanDetails: ScanDetails
  canBeCleaned: boolean
  scannedAt: string
  relativePath?: string
}

interface URLScanResult {
  url: string
  finalUrl: string
  title: string
  status: 'safe' | 'suspicious' | 'malicious' | 'error'
  threatLevel: number
  threats: any[]
  ssl: boolean
  recommendations: string[]
  contentAnalysis: {
    hasLoginForm: boolean
    hasPasswordField: boolean
    hasDownloadButton: boolean
    hasExternalScripts: boolean
    scriptCount: number
    iframeCount: number
  }
}

interface HistoryItem {
  id: string
  fileName: string
  fileSize: number
  status: string
  threatLevel: number
  scannedAt: string
}

interface CleanResult {
  success: boolean
  fileName: string
  bytesRemoved: number
  removedThreats: number
  threatNames: string[]
  remainingThreats: string[]
  newThreatLevel: number
  cleanedFileBase64: string
}

interface FileToScan {
  id: string
  file: File
  relativePath?: string
  type: 'file' | 'folder'
}

export default function Home() {
  const [activeTab, setActiveTab] = useState('file')
  const [isDragging, setIsDragging] = useState(false)
  const [isScanning, setIsScanning] = useState(false)
  const [isCleaning, setIsCleaning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [multiScanResults, setMultiScanResults] = useState<ScanResult[]>([])
  const [cleanResult, setCleanResult] = useState<CleanResult | null>(null)
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [selectedFiles, setSelectedFiles] = useState<FileToScan[]>([])
  const [currentScanningIndex, setCurrentScanningIndex] = useState(0)
  const [scanMode, setScanMode] = useState<'single' | 'multi'>('single')
  
  // Refs for hidden inputs
  const filesInputRef = useRef<HTMLInputElement>(null)
  const foldersInputRef = useRef<HTMLInputElement>(null)
  
  // URL scan states
  const [urlInput, setUrlInput] = useState('')
  const [isUrlScanning, setIsUrlScanning] = useState(false)
  const [urlScanResult, setUrlScanResult] = useState<URLScanResult | null>(null)

  const fetchHistory = useCallback(async () => {
    try {
      const response = await fetch('/api/scan/history')
      if (response.ok) {
        const data = await response.json()
        setHistory(data)
      }
    } catch (error) {
      console.error('Failed to fetch history:', error)
    }
  }, [])

  useEffect(() => {
    fetchHistory()
  }, [fetchHistory])

  // Generate unique ID for files
  const generateFileId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

  // Handle drag events
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  // Unified drop handler for both files and folders
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const items = e.dataTransfer.items
    const filesToScan: FileToScan[] = []
    
    const traverseFileTree = async (item: any, path = ''): Promise<void> => {
      if (item.isFile) {
        const file = item.getAsFile()
        if (file) {
          filesToScan.push({ 
            id: generateFileId(),
            file, 
            relativePath: path + file.name,
            type: 'file'
          })
        }
      } else if (item.isDirectory) {
        const dirReader = item.createReader()
        const entries = await new Promise<any[]>((resolve) => {
          dirReader.readEntries(resolve)
        })
        for (const entry of entries) {
          await traverseFileTree(entry, path + item.name + '/')
        }
      }
    }
    
    for (let i = 0; i < items.length; i++) {
      const item = items[i].webkitGetAsEntry()
      if (item) {
        await traverseFileTree(item)
      }
    }
    
    if (filesToScan.length > 0) {
      // Mark as folder type if any file has a path separator
      const hasFolder = filesToScan.some(f => f.relativePath?.includes('/'))
      filesToScan.forEach(f => {
        if (f.relativePath?.includes('/')) {
          f.type = 'folder'
        }
      })
      
      setSelectedFiles(prev => [...prev, ...filesToScan])
      setSelectedFile(null)
      setScanMode('multi')
      setScanResult(null)
      setCleanResult(null)
      setMultiScanResults([])
      toast.success(`${filesToScan.length} Dateien hinzugefügt`)
    }
  }, [])

  // Handle multiple files selection
  const handleFilesSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const filesToAdd: FileToScan[] = []
      for (let i = 0; i < files.length; i++) {
        filesToAdd.push({
          id: generateFileId(),
          file: files[i],
          relativePath: files[i].name,
          type: 'file'
        })
      }
      setSelectedFiles(prev => [...prev, ...filesToAdd])
      setSelectedFile(null)
      setScanMode('multi')
      setScanResult(null)
      setCleanResult(null)
      setMultiScanResults([])
      toast.success(`${filesToAdd.length} Dateien hinzugefügt`)
    }
    // Reset input
    e.target.value = ''
  }, [])

  // Handle multiple folders selection
  const handleFoldersSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const filesToAdd: FileToScan[] = []
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        filesToAdd.push({
          id: generateFileId(),
          file,
          relativePath: (file as any).webkitRelativePath || file.name,
          type: 'folder'
        })
      }
      setSelectedFiles(prev => [...prev, ...filesToAdd])
      setSelectedFile(null)
      setScanMode('multi')
      setScanResult(null)
      setCleanResult(null)
      setMultiScanResults([])
      toast.success(`${filesToAdd.length} Dateien aus Ordnern hinzugefügt`)
    }
    // Reset input
    e.target.value = ''
  }, [])

  // Remove a single file from selection
  const removeFile = useCallback((id: string) => {
    setSelectedFiles(prev => prev.filter(f => f.id !== id))
  }, [])

  // Clear all selected files
  const clearAllFiles = useCallback(() => {
    setSelectedFiles([])
    setSelectedFile(null)
    setMultiScanResults([])
    setScanResult(null)
    setCleanResult(null)
  }, [])

  // Scan a single file
  const scanFile = async (fileToScan?: FileToScan) => {
    const targetFile = fileToScan?.file || selectedFile
    const relativePath = fileToScan?.relativePath
    
    if (!targetFile) return null

    const formData = new FormData()
    formData.append('file', targetFile)
    if (relativePath) {
      formData.append('relativePath', relativePath)
    }

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        body: formData
      })

      if (response.ok) {
        return await response.json()
      } else {
        return null
      }
    } catch (error) {
      return null
    }
  }

  // Start single file scan
  const startSingleScan = async () => {
    if (!selectedFile) return

    setIsScanning(true)
    setScanProgress(0)
    setCleanResult(null)
    setScanResult({
      id: '',
      fileName: selectedFile.name,
      fileSize: selectedFile.size,
      fileType: selectedFile.type || 'unknown',
      fileHash: '',
      status: 'scanning',
      threatLevel: 0,
      threats: [],
      scanDetails: {
        entropy: 0,
        packedFiles: 0,
        suspiciousStrings: [],
        networkIndicators: [],
        registryModifications: [],
        permissions: [],
        fakeAlertsDetected: false,
        notificationAbuse: false,
        fileTypeCategory: 'unknown',
        scanMode: '100% Vollständig',
        fileSizeCategory: 'Klein',
        samplesAnalyzed: 1,
        scanTime: 0,
        scriptType: '',
        totalPatterns: 0,
        linesScanned: 0,
        patternsChecked: 0,
        categoriesFound: []
      },
      canBeCleaned: false,
      scannedAt: new Date().toISOString()
    })

    const progressInterval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return prev
        }
        return prev + Math.random() * 25
      })
    }, 100)

    const result = await scanFile()
    
    clearInterval(progressInterval)
    setScanProgress(100)

    if (result) {
      setScanResult(result)
      fetchHistory()
      
      if (result.status === 'safe') {
        toast.success('Datei ist sicher!')
      } else if (result.status === 'suspicious') {
        toast.warning('Verdächtige Datei erkannt!')
      } else if (result.status === 'malicious') {
        toast.error('Gefährliche Datei erkannt!')
      }
    } else {
      setScanResult(prev => prev ? { ...prev, status: 'error' } : null)
      toast.error('Scan fehlgeschlagen')
    }
    
    setIsScanning(false)
  }

  // Start multi-file scan
  const startMultiScan = async () => {
    if (selectedFiles.length === 0) return

    setIsScanning(true)
    setScanProgress(0)
    setMultiScanResults([])
    setCurrentScanningIndex(0)

    const results: ScanResult[] = []

    for (let i = 0; i < selectedFiles.length; i++) {
      setCurrentScanningIndex(i + 1)
      setScanProgress(((i + 1) / selectedFiles.length) * 100)

      const result = await scanFile(selectedFiles[i])
      if (result) {
        results.push(result)
        setMultiScanResults([...results])
      }
    }

    fetchHistory()
    setIsScanning(false)
    
    const safeCount = results.filter(r => r.status === 'safe').length
    const suspiciousCount = results.filter(r => r.status === 'suspicious').length
    const maliciousCount = results.filter(r => r.status === 'malicious').length
    
    toast.success(
      `Scan abgeschlossen: ${safeCount} sicher, ${suspiciousCount} verdächtig, ${maliciousCount} gefährlich`
    )
  }

  // URL scan
  const scanUrl = async () => {
    if (!urlInput.trim()) {
      toast.error('Bitte geben Sie eine URL ein')
      return
    }

    setIsUrlScanning(true)
    setUrlScanResult(null)

    try {
      const response = await fetch('/api/url-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlInput })
      })

      if (response.ok) {
        const result = await response.json()
        setUrlScanResult(result)
        
        if (result.status === 'safe') {
          toast.success('Website ist sicher!')
        } else if (result.status === 'suspicious') {
          toast.warning('Verdächtige Website!')
        } else if (result.status === 'malicious') {
          toast.error('Gefährliche Website!')
        }
      } else {
        toast.error('URL-Scan fehlgeschlagen')
        setUrlScanResult({
          url: urlInput,
          finalUrl: urlInput,
          title: '',
          status: 'error',
          threatLevel: 0,
          threats: [],
          ssl: false,
          recommendations: ['Fehler beim Scannen der URL'],
          contentAnalysis: {
            hasLoginForm: false,
            hasPasswordField: false,
            hasDownloadButton: false,
            hasExternalScripts: false,
            scriptCount: 0,
            iframeCount: 0
          }
        })
      }
    } catch (error) {
      toast.error('URL-Scan fehlgeschlagen')
    } finally {
      setIsUrlScanning(false)
    }
  }

  // Clean file
  const cleanFile = async () => {
    if (!selectedFile || !scanResult) return

    setIsCleaning(true)

    const formData = new FormData()
    formData.append('file', selectedFile)
    if (scanResult.id) {
      formData.append('scanId', scanResult.id)
    }

    try {
      const response = await fetch('/api/scan/clean', {
        method: 'POST',
        body: formData
      })

      if (response.ok) {
        const result = await response.json()
        setCleanResult(result)
        
        if (result.removedThreats > 0) {
          toast.success(`${result.removedThreats} Bedrohungen entfernt!`)
        } else {
          toast.info('Keine automatisch entfernenden Bedrohungen gefunden')
        }
      } else {
        toast.error('Reinigung fehlgeschlagen')
      }
    } catch (error) {
      toast.error('Reinigung fehlgeschlagen')
    } finally {
      setIsCleaning(false)
    }
  }

  // Download cleaned file
  const downloadCleanedFile = () => {
    if (!cleanResult || !scanResult) return

    const binaryString = atob(cleanResult.cleanedFileBase64)
    const bytes = new Uint8Array(binaryString.length)
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i)
    }
    
    const blob = new Blob([bytes], { type: scanResult.fileType || 'application/octet-stream' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `cleaned_${scanResult.fileName}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    
    toast.success('Bereinigte Datei heruntergeladen!')
  }

  // Helper functions
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe': return <ShieldCheck className="h-8 w-8 text-green-500" />
      case 'suspicious': return <ShieldAlert className="h-8 w-8 text-yellow-500" />
      case 'malicious': return <ShieldX className="h-8 w-8 text-red-500" />
      case 'scanning': return <RefreshCw className="h-8 w-8 text-blue-500 animate-spin" />
      default: return <Shield className="h-8 w-8 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'safe': return 'bg-green-500'
      case 'suspicious': return 'bg-yellow-500'
      case 'malicious': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getThreatBadge = (severity: string) => {
    switch (severity) {
      case 'low': return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Niedrig</Badge>
      case 'medium': return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Mittel</Badge>
      case 'high': return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Hoch</Badge>
      case 'critical': return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Kritisch</Badge>
      default: return <Badge variant="outline">Unbekannt</Badge>
    }
  }

  const getThreatIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'virus': return <AlertOctagon className="h-4 w-4 text-red-500" />
      case 'trojan': return <Skull className="h-4 w-4 text-red-600" />
      case 'malware': return <BugPlay className="h-4 w-4 text-orange-500" />
      case 'ransomware': return <Ban className="h-4 w-4 text-red-600" />
      case 'phishing': return <Globe className="h-4 w-4 text-purple-500" />
      default: return <AlertCircle className="h-4 w-4 text-yellow-500" />
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const clearHistory = async () => {
    try {
      await fetch('/api/scan/history', { method: 'DELETE' })
      setHistory([])
      toast.success('Verlauf gelöscht')
    } catch (error) {
      toast.error('Löschen fehlgeschlagen')
    }
  }

  // Calculate totals
  const totalFilesSize = selectedFiles.reduce((sum, f) => sum + f.file.size, 0)
  const fileCount = selectedFiles.filter(f => f.type === 'file').length
  const folderCount = selectedFiles.filter(f => f.type === 'folder').length

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Shield className="h-10 w-10 text-emerald-400" />
                <div className="absolute -top-1 -right-1 h-4 w-4 bg-emerald-500 rounded-full animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">SecureScan Pro</h1>
                <p className="text-sm text-slate-400">Malware & Security Scanner • Bis zu 50GB • Multi-Upload</p>
              </div>
            </div>
            <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/50">
              <div className="h-2 w-2 bg-emerald-400 rounded-full mr-2 animate-pulse" />
              Bereit
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Upload & URL */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-800/50 border border-slate-700">
                <TabsTrigger value="file" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                  <Layers className="h-4 w-4 mr-2" />
                  Dateien & Ordner
                </TabsTrigger>
                <TabsTrigger value="url" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                  <Link className="h-4 w-4 mr-2" />
                  URL prüfen
                </TabsTrigger>
              </TabsList>

              {/* File Scan Tab */}
              <TabsContent value="file" className="space-y-6 mt-4">
                {/* Unified Upload Area */}
                <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Upload className="h-5 w-5 text-emerald-400" />
                      Dateien & Ordner hochladen
                    </CardTitle>
                    <CardDescription className="text-slate-400">
                      Fügen Sie mehrere Dateien oder ganze Ordner hinzu - bis zu 50GB
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Drop Zone */}
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      className={`
                        border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300
                        ${isDragging 
                          ? 'border-emerald-400 bg-emerald-400/10 scale-[1.02]' 
                          : 'border-slate-600 hover:border-slate-500 bg-slate-900/50'}
                      `}
                    >
                      <Upload className={`h-16 w-16 mx-auto mb-4 transition-colors ${isDragging ? 'text-emerald-400' : 'text-slate-500'}`} />
                      <p className="text-lg font-medium text-white mb-2">
                        {isDragging ? 'Hier ablegen...' : 'Dateien oder Ordner hierher ziehen'}
                      </p>
                      <p className="text-sm text-slate-400 mb-4">
                        oder nutzen Sie die Buttons unten
                      </p>
                      
                      <div className="flex flex-wrap items-center justify-center gap-3 mb-4">
                        <Badge variant="outline" className="text-emerald-400 border-emerald-500/50">
                          <HardDrive className="h-3 w-3 mr-1" />
                          Bis zu 50 GB
                        </Badge>
                        <Badge variant="outline" className="text-blue-400 border-blue-500/50">
                          <Files className="h-3 w-3 mr-1" />
                          Mehrere Dateien
                        </Badge>
                        <Badge variant="outline" className="text-purple-400 border-purple-500/50">
                          <FolderOpen className="h-3 w-3 mr-1" />
                          Ganze Ordner
                        </Badge>
                      </div>
                      
                      {/* Action Buttons */}
                      <div className="flex flex-wrap items-center justify-center gap-3">
                        <Button 
                          variant="outline" 
                          className="border-emerald-600 text-emerald-300 hover:bg-emerald-700/20"
                          onClick={() => filesInputRef.current?.click()}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Dateien hinzufügen
                        </Button>
                        <Button 
                          variant="outline" 
                          className="border-purple-600 text-purple-300 hover:bg-purple-700/20"
                          onClick={() => foldersInputRef.current?.click()}
                        >
                          <FolderPlus className="h-4 w-4 mr-2" />
                          Ordner hinzufügen
                        </Button>
                      </div>
                      
                      {/* Hidden Inputs */}
                      <input
                        ref={filesInputRef}
                        type="file"
                        className="hidden"
                        onChange={handleFilesSelect}
                        multiple
                      />
                      <input
                        ref={foldersInputRef}
                        type="file"
                        className="hidden"
                        onChange={handleFoldersSelect}
                        //@ts-ignore
                        webkitdirectory=""
                        directory=""
                        multiple
                      />
                    </div>

                    {/* Selected Files List */}
                    {selectedFiles.length > 0 && (
                      <div className="mt-4 p-4 rounded-lg bg-slate-900/50 border border-emerald-500/30">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Files className="h-5 w-5 text-emerald-400" />
                            <div>
                              <span className="font-medium text-white">
                                {selectedFiles.length} Dateien ausgewählt
                              </span>
                              <span className="text-sm text-slate-400 ml-2">
                                ({formatFileSize(totalFilesSize)} gesamt)
                              </span>
                            </div>
                            {fileCount > 0 && (
                              <Badge variant="outline" className="text-blue-400 border-blue-500/50">
                                {fileCount} Dateien
                              </Badge>
                            )}
                            {folderCount > 0 && (
                              <Badge variant="outline" className="text-purple-400 border-purple-500/50">
                                {folderCount} aus Ordnern
                              </Badge>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={clearAllFiles}
                              className="text-slate-400 hover:text-red-400"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Alle löschen
                            </Button>
                            <Button
                              onClick={startMultiScan}
                              disabled={isScanning}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white"
                            >
                              {isScanning ? (
                                <>
                                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                  Scanne {currentScanningIndex}/{selectedFiles.length}...
                                </>
                              ) : (
                                <>
                                  <FileSearch className="h-4 w-4 mr-2" />
                                  Alle scannen
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                        
                        <ScrollArea className="max-h-48">
                          <div className="space-y-1">
                            {selectedFiles.map((f) => (
                              <div key={f.id} className="flex items-center justify-between p-2 rounded bg-slate-800/50 hover:bg-slate-800 group">
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  {f.type === 'folder' ? (
                                    <FolderOpen className="h-4 w-4 text-purple-400 flex-shrink-0" />
                                  ) : (
                                    <FileText className="h-4 w-4 text-blue-400 flex-shrink-0" />
                                  )}
                                  <span className="text-slate-300 truncate text-sm">{f.relativePath || f.file.name}</span>
                                  <span className="text-slate-500 text-xs">{formatFileSize(f.file.size)}</span>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-400"
                                  onClick={() => removeFile(f.id)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    )}

                    {/* Multi-Scan Progress */}
                    {isScanning && scanMode === 'multi' && (
                      <div className="mt-4 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-400">Scanne {currentScanningIndex} von {selectedFiles.length}...</span>
                          <span className="text-emerald-400">{Math.round(scanProgress)}%</span>
                        </div>
                        <Progress value={scanProgress} className="h-2 bg-slate-700" />
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Multi-Scan Results */}
                {multiScanResults.length > 0 && (
                  <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Files className="h-5 w-5 text-emerald-400" />
                        Scan-Ergebnisse ({multiScanResults.length} Dateien)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/30 text-center">
                          <p className="text-2xl font-bold text-green-400">
                            {multiScanResults.filter(r => r.status === 'safe').length}
                          </p>
                          <p className="text-xs text-slate-400">Sicher</p>
                        </div>
                        <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30 text-center">
                          <p className="text-2xl font-bold text-yellow-400">
                            {multiScanResults.filter(r => r.status === 'suspicious').length}
                          </p>
                          <p className="text-xs text-slate-400">Verdächtig</p>
                        </div>
                        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-center">
                          <p className="text-2xl font-bold text-red-400">
                            {multiScanResults.filter(r => r.status === 'malicious').length}
                          </p>
                          <p className="text-xs text-slate-400">Gefährlich</p>
                        </div>
                      </div>
                      
                      <ScrollArea className="max-h-96">
                        <div className="space-y-2">
                          {multiScanResults.map((result, index) => (
                            <div key={index} className="p-3 rounded-lg bg-slate-900/50 border border-slate-700">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3 flex-1 min-w-0">
                                  {getStatusIcon(result.status)}
                                  <div className="min-w-0 flex-1">
                                    <p className="font-medium text-white truncate">{result.fileName}</p>
                                    <p className="text-xs text-slate-400">
                                      {formatFileSize(result.fileSize)} • {result.threats.length} Bedrohungen
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className={`text-sm font-medium ${
                                    result.threatLevel > 70 ? 'text-red-400' : 
                                    result.threatLevel > 30 ? 'text-yellow-400' : 'text-green-400'
                                  }`}>
                                    {result.threatLevel}%
                                  </span>
                                  <Badge className={`${getStatusColor(result.status)} text-white text-xs`}>
                                    {result.status === 'safe' && 'OK'}
                                    {result.status === 'suspicious' && '?!'}
                                    {result.status === 'malicious' && '!!'}
                                  </Badge>
                                </div>
                              </div>
                              {result.threats.length > 0 && (
                                <div className="mt-2 pt-2 border-t border-slate-700">
                                  <div className="flex flex-wrap gap-1">
                                    {result.threats.slice(0, 3).map((t, i) => (
                                      <Badge key={i} variant="outline" className="text-xs bg-red-500/10 text-red-300 border-red-500/30">
                                        {t.type}
                                      </Badge>
                                    ))}
                                    {result.threats.length > 3 && (
                                      <Badge variant="outline" className="text-xs bg-slate-500/10 text-slate-300">
                                        +{result.threats.length - 3}
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                )}

                {/* Single File Scan Result */}
                {scanResult && scanResult.status !== 'scanning' && scanMode === 'single' && (
                  <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                          {getStatusIcon(scanResult.status)}
                          Scan-Ergebnis
                        </CardTitle>
                        <div className="flex items-center gap-2">
                          {scanResult.canBeCleaned && scanResult.status !== 'safe' && (
                            <Button
                              onClick={cleanFile}
                              disabled={isCleaning}
                              className="bg-purple-600 hover:bg-purple-700 text-white"
                            >
                              {isCleaning ? (
                                <>
                                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                  Bereinige...
                                </>
                              ) : (
                                <>
                                  <Sparkles className="h-4 w-4 mr-2" />
                                  Bereinigen
                                </>
                              )}
                            </Button>
                          )}
                          <Badge className={`${getStatusColor(scanResult.status)} text-white`}>
                            {scanResult.status === 'safe' && 'Sicher'}
                            {scanResult.status === 'suspicious' && 'Verdächtig'}
                            {scanResult.status === 'malicious' && 'Gefährlich'}
                            {scanResult.status === 'error' && 'Fehler'}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Fake Alert Warning */}
                      {scanResult.scanDetails.fakeAlertsDetected && (
                        <Alert className="bg-red-500/20 border-red-500 animate-pulse">
                          <AlertTriangle className="h-5 w-5 text-red-500" />
                          <AlertTitle className="text-red-400 font-bold text-lg">⚠️ FAKE-VIRENWARNUNG ERKANNT!</AlertTitle>
                          <AlertDescription className="text-red-300">
                            Diese Datei enthält gefälschte Virenwarnungen oder Tech-Support-Scams.
                            <strong className="block mt-2">Ignorieren Sie KEINE Warnungen dieser Datei!</strong>
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Clean Result */}
                      {cleanResult && (
                        <Alert className="bg-purple-500/10 border-purple-500">
                          <Sparkles className="h-5 w-5 text-purple-400" />
                          <AlertTitle className="text-purple-400">Bereinigung abgeschlossen!</AlertTitle>
                          <AlertDescription className="text-purple-300/80">
                            <div className="mt-2 space-y-1">
                              <p>✓ {cleanResult.removedThreats} Bedrohungen entfernt</p>
                              <p>✓ {formatFileSize(cleanResult.bytesRemoved)} bereinigt</p>
                            </div>
                            <Button
                              onClick={downloadCleanedFile}
                              className="mt-3 bg-purple-600 hover:bg-purple-700"
                              size="sm"
                            >
                              <Download className="h-4 w-4 mr-2" />
                              Bereinigte Datei herunterladen
                            </Button>
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* File Info */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="p-3 rounded-lg bg-slate-900/50">
                          <p className="text-xs text-slate-400">Dateiname</p>
                          <p className="text-sm font-medium text-white truncate">{scanResult.fileName}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-slate-900/50">
                          <p className="text-xs text-slate-400">Größe</p>
                          <p className="text-sm font-medium text-white">{formatFileSize(scanResult.fileSize)}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-slate-900/50">
                          <p className="text-xs text-slate-400">Bedrohungslevel</p>
                          <p className={`text-sm font-medium ${scanResult.threatLevel > 70 ? 'text-red-400' : scanResult.threatLevel > 30 ? 'text-yellow-400' : 'text-green-400'}`}>
                            {scanResult.threatLevel}%
                          </p>
                        </div>
                        <div className="p-3 rounded-lg bg-slate-900/50">
                          <p className="text-xs text-slate-400">Scan-Zeit</p>
                          <p className="text-sm font-medium text-emerald-400">
                            {scanResult.scanDetails?.scanTime ? `${scanResult.scanDetails.scanTime}ms` : '< 1s'}
                          </p>
                        </div>
                      </div>

                      {/* Threat Level Progress */}
                      <div className="space-y-2">
                        <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-500 ${
                              scanResult.threatLevel > 70 ? 'bg-red-500' : 
                              scanResult.threatLevel > 30 ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${scanResult.threatLevel}%` }}
                          />
                        </div>
                      </div>

                      {/* Detected Threats */}
                      {scanResult.threats.length > 0 && (
                        <div className="space-y-3">
                          <h4 className="font-medium text-white flex items-center gap-2">
                            <AlertTriangle className="h-4 w-4 text-yellow-400" />
                            Erkannte Bedrohungen ({scanResult.threats.length})
                          </h4>
                          <ScrollArea className="max-h-64">
                            <div className="space-y-2">
                              {scanResult.threats.map((threat, index) => (
                                <div key={index} className="p-3 rounded-lg bg-slate-900/50 border border-slate-700">
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      {getThreatIcon(threat.type)}
                                      <span className="font-medium text-white">{threat.type}</span>
                                      {threat.removable && (
                                        <Badge variant="outline" className="text-xs bg-purple-500/20 text-purple-300">
                                          Entfernbar
                                        </Badge>
                                      )}
                                      {threat.line && (
                                        <Badge variant="outline" className="text-xs bg-blue-500/20 text-blue-300">
                                          Zeile {threat.line}
                                        </Badge>
                                      )}
                                    </div>
                                    {getThreatBadge(threat.severity)}
                                  </div>
                                  <p className="text-sm text-slate-400">{threat.description}</p>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* URL Scan Tab */}
              <TabsContent value="url" className="space-y-6 mt-4">
                <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Link className="h-5 w-5 text-emerald-400" />
                      Website-URL prüfen
                    </CardTitle>
                    <CardDescription className="text-slate-400">
                      Geben Sie eine URL ein, um sie auf Phishing, Malware und Betrug zu prüfen
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-3">
                      <div className="flex-1">
                        <Input
                          type="url"
                          placeholder="https://example.com"
                          value={urlInput}
                          onChange={(e) => setUrlInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && scanUrl()}
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                      <Button
                        onClick={scanUrl}
                        disabled={isUrlScanning || !urlInput.trim()}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white px-6"
                      >
                        {isUrlScanning ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Prüfe...
                          </>
                        ) : (
                          <>
                            <Globe className="h-4 w-4 mr-2" />
                            URL prüfen
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* URL Scan Result */}
                {urlScanResult && (
                  <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white flex items-center gap-2">
                          {getStatusIcon(urlScanResult.status)}
                          URL-Analyse
                        </CardTitle>
                        <Badge className={`${getStatusColor(urlScanResult.status)} text-white`}>
                          {urlScanResult.status === 'safe' && 'Sicher'}
                          {urlScanResult.status === 'suspicious' && 'Verdächtig'}
                          {urlScanResult.status === 'malicious' && 'Gefährlich'}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-700">
                        <div className="flex items-center gap-2">
                          {urlScanResult.ssl ? (
                            <Lock className="h-5 w-5 text-green-400" />
                          ) : (
                            <LockOpen className="h-5 w-5 text-red-400" />
                          )}
                          <span className="text-white font-medium truncate">{urlScanResult.url}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-400">Bedrohungs-Score</span>
                          <span className={urlScanResult.threatLevel > 70 ? 'text-red-400' : urlScanResult.threatLevel > 30 ? 'text-yellow-400' : 'text-green-400'}>
                            {urlScanResult.threatLevel}%
                          </span>
                        </div>
                        <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-500 ${
                              urlScanResult.threatLevel > 70 ? 'bg-red-500' : 
                              urlScanResult.threatLevel > 30 ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${urlScanResult.threatLevel}%` }}
                          />
                        </div>
                      </div>

                      {urlScanResult.threats.length > 0 && (
                        <div className="space-y-2">
                          {urlScanResult.threats.map((threat: any, index: number) => (
                            <div key={index} className="p-3 rounded-lg bg-slate-900/50 border border-slate-700">
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-medium text-white">{threat.type}</span>
                                {getThreatBadge(threat.severity)}
                              </div>
                              <p className="text-sm text-slate-400">{threat.description}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Column - History & Stats */}
          <div className="space-y-6">
            {/* Statistics */}
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="h-5 w-5 text-emerald-400" />
                  Statistiken
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 rounded-lg bg-slate-900/50">
                    <p className="text-3xl font-bold text-white">{history.length}</p>
                    <p className="text-sm text-slate-400">Scans</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-slate-900/50">
                    <p className="text-3xl font-bold text-red-400">
                      {history.filter(h => h.status === 'malicious').length}
                    </p>
                    <p className="text-sm text-slate-400">Gefunden</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Scan History */}
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="h-5 w-5 text-emerald-400" />
                    Verlauf
                  </CardTitle>
                  {history.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearHistory}
                      className="text-slate-400 hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {history.length === 0 ? (
                  <div className="text-center py-8">
                    <Shield className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400">Noch keine Scans</p>
                  </div>
                ) : (
                  <ScrollArea className="max-h-80">
                    <div className="space-y-2">
                      {history.map((item) => (
                        <div key={item.id} className="p-3 rounded-lg bg-slate-900/50 border border-slate-700">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 min-w-0">
                              {getStatusIcon(item.status)}
                              <div className="min-w-0">
                                <p className="text-sm font-medium text-white truncate">{item.fileName}</p>
                                <p className="text-xs text-slate-400">
                                  {formatFileSize(item.fileSize)} • {new Date(item.scannedAt).toLocaleDateString('de-DE')}
                                </p>
                              </div>
                            </div>
                            <Badge className={`${getStatusColor(item.status)} text-white text-xs`}>
                              {item.threatLevel}%
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>

            {/* Features */}
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-emerald-400" />
                  Funktionen
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                      <HardDrive className="h-4 w-4 text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">Bis zu 50GB</p>
                      <p className="text-xs text-slate-400">Große Dateien scannen</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                      <Files className="h-4 w-4 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">Multi-Upload</p>
                      <p className="text-xs text-slate-400">Mehrere Dateien gleichzeitig</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                      <FolderOpen className="h-4 w-4 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">Ordner-Scan</p>
                      <p className="text-xs text-slate-400">Ganze Ordner scannen</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-orange-500/20 flex items-center justify-center">
                      <Sparkles className="h-4 w-4 text-orange-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">Bereinigung</p>
                      <p className="text-xs text-slate-400">Bedrohungen entfernen</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 backdrop-blur-sm py-4 mt-auto">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-slate-400">
            SecureScan Pro • Multi-Upload • Bis zu 50GB • Ordner & Dateien
          </p>
        </div>
      </footer>
    </div>
  )
}
