import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  experimental: {
    // Enable larger request body size for file uploads (50GB)
    serverActions: {
      bodySizeLimit: '50gb',
    },
  },
  // Increase API body size limit
  api: {
    bodyParser: {
      sizeLimit: '50gb',
    },
    responseLimit: '50gb',
  },
};

export default nextConfig;
